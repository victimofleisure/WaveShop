#ifndef _CONFIG_H
#define _CONFIG_H

#undef EXPLICIT_S
#undef ACCEL_3DNOW
#undef HAVE_LRINTF
#undef PACKAGE_LOCALE_DIR
#undef PACKAGE_DATA_DIR

#endif
