// libmp4adtest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveShop.h"
#include "libmp4adtest.h"
extern "C" {
#include "libmp4ad.h"
};
#include "Wave.h"
#include "MP4DecodeWrap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWaveShopApp	theApp;

FILE	*fp;

int	channels;
int	samprate;
int	samps;
int	desiredsampsize = 3;
CByteArray	convbuf;
int	toterrs;
int	toterrmsglen;
CString	lasterr;

int OnOutput(void *param, long total_samples, long samples, const NeAACDecFrameInfo *frame_info, const void *sample_buffer)
{
	if (fp == NULL) {
		fp = fopen("out.tmp", "w+b");
		if (fp == NULL) {
			printf("can't open output file\n");
			return(1);
		}
		channels = frame_info->channels;
		samprate = frame_info->samplerate;
printf("channels=%d samplerate=%d\n", frame_info->channels, frame_info->samplerate);
		if (desiredsampsize == 3) {
			convbuf.SetSize(frame_info->samples * 3);
		}
	}
	const void	*outbuf;
	int	framesize = frame_info->channels;//@@@???
	if (desiredsampsize == 3) {
		const BYTE *pIn = (const BYTE *)sample_buffer;
		BYTE *pOut = convbuf.GetData();
		for (UINT i = 0; i < frame_info->samples; i++) {
			memcpy(pOut, pIn, 3);
			pIn += 4;
			pOut += 3;
		}
		outbuf = convbuf.GetData();
	} else
		outbuf = sample_buffer;
	fwrite(outbuf, desiredsampsize, frame_info->samples, fp);
//	printf("%d\n", frame_info->samples);
	printf("%d\r", int(samples / double(total_samples) * 100 + .5));
	samps += frame_info->samples;
	return(0);	// non-zero to abort decoding
}

void OnError(void *param, const char *error_message)
{
	fputs(error_message, stdout);
	toterrmsglen += strlen(error_message);
	toterrs++;
	lasterr = CString(error_message);
}

bool test(LPCTSTR Path)
{
	aac_dec_opt opt;
	memset(&opt, 0, sizeof(opt));
	opt.on_output = OnOutput;
	opt.on_error = OnError;
	switch (desiredsampsize) {
	case 2:
		opt.output_format = FAAD_FMT_16BIT;
		break;
	case 3:
		opt.output_format = FAAD_FMT_24BIT;
		break;
	case 4:
		opt.output_format = FAAD_FMT_32BIT;
		break;
	default:
		printf("unsupported sample size\n");
		return(FALSE);
	}
//		opt.down_matrix = 1;
	int	retc = aac_decode(Path, &opt);
printf("retc=%d\n", retc);
	if (!retc)	// if decoding failed
		return(FALSE);
	if (fp == NULL) {
		printf("output stream not created\n");
		return(FALSE);
	}
	CWave	wave;
	wave.SetFormat(channels, samprate, desiredsampsize << 3);
	int	frames = samps / channels;
printf("frames=%d\n", frames);
	wave.SetFrameCount(frames);
	fflush(fp);
	rewind(fp);
	fread(wave.GetData(), wave.GetFrameSize(), frames, fp);
	fclose(fp);
	if (!wave.SafeWrite("test.wav")) {
		printf("can't write wave\n");
		return(FALSE);
	}
	if (!lasterr.IsEmpty())
		printf("error=%s\n", lasterr);
printf("toterrs=%d toterrmsglen=%d\n", toterrs, toterrmsglen);
	return(TRUE);
}

bool test2(LPCTSTR Path)
{
	CMP4DecodeWrap	 lib;
	CWave	wave;
	int	Quality = CMP4DecodeWrap::QUAL_16_BIT;
	bool	Downmix = FALSE;
	if (!lib.Create(Quality, Downmix)) {
		printf("can't create lib\n");
		return(FALSE);
	}
	if (!lib.Read(Path, wave)) {
		printf("decode failed\n");
		return(FALSE);
	}
	if (!wave.SafeWrite("test.wav")) {
		printf("can't write wave\n");
		return(FALSE);
	}
	return(TRUE);
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		printf("Fatal Error: MFC initialization failed\n");
		nRetCode = 1;
	}
	else
	{
		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\iTunes_test1_AAC-LC_v4_Stereo_VBR_128kbps_44100Hz.m4a";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\iTunes_test1_AAC-LC_v4_Stereo_VBR_128kbps_44100Hz DAMAGED.m4a";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\test.m4a";	// surround
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\01.m4a";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\sample.aac";	// piano solo
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\aquatisme.aac";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\aquatisme DAMAGED.aac";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\sample1.zip";
//		LPCTSTR	Path = "C:\\temp\\wav\\AAC\\empty.txt";
//		test(Path);
		test2(Path);
	}

	return nRetCode;
}
