//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by libmp4adtest.rc
//
#define IDS_HELLO                       1
#define IDD_PROGRESS                    132
#define IDD_PROGRESS_DUAL               133
#define IDD_PROGRESS_SLAVE              134
#define IDS_CKUP_CANT_LOAD_DLL          208
#define IDS_DLL_CANT_GET_FUNCTION       214
#define IDS_WAVE_ERR_BAD_BIT_COUNT      333
#define IDS_WAVE_ERR_BAD_BLOCK_ALIGN    334
#define IDS_WAVE_ERR_BAD_CHANNEL_COUNT  335
#define IDS_WAVE_ERR_BAD_FORMAT_SIZE    336
#define IDS_WAVE_ERR_BAD_SAMPLE_RATE    337
#define IDS_WAVE_ERR_END_OF_FILE        338
#define IDS_WAVE_ERR_NOT_RIFF           339
#define IDS_WAVE_ERR_NOT_WAVE           340
#define IDS_WAVE_ERR_NO_DATA_CHUNK      341
#define IDS_WAVE_ERR_NO_FORMAT_CHUNK    342
#define IDS_WAVE_ERR_UNKNOWN_FORMAT     343
#define IDS_WEDT_NO_TEMP_FILE_NAME      353
#define IDS_DOC_READING                 354
#define IDC_PROGRESS                    1095
#define IDC_PROGRESS_PERCENT            1096
#define IDC_PROGRESS_SUBCAPTION         1097
#define IDC_PROGRESS_SUBPROGRESS        1098

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
