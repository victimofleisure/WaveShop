typedef int (*paac_decode)(const char *path, const aac_dec_opt *opt);
