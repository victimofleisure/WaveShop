#ifndef CWAVESHOPAPP_INCLUDED
#define CWAVESHOPAPP_INCLUDED

#include "Resource.h"

class CDLLWrap;

class CWaveShopApp : public CWinApp {
public:
	CString GetAppPath();
	CString GetAppFolder();
	bool	GetTempPath(CString& Path);
	bool	GetTempFileName(CString& Path, LPCTSTR Prefix = NULL, UINT Unique = 0);
	static	bool	GetDLLFunctions(CDLLWrap& Lib, LPCTSTR LibPath, const int *OrdinalTbl, int Functions, CPtrArray& FuncPtr);
	static	FILE	*OpenTempStream(LPCTSTR Path);
};

extern CWaveShopApp theApp;

#endif
