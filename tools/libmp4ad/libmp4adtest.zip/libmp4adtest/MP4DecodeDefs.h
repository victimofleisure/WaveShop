MP4_DEF(aac_decode,        1)

#undef MP4_DEF
