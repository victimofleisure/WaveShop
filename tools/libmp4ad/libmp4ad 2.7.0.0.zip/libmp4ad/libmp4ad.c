/*
** FAAD - Freeware Advanced Audio Decoder
** Copyright (C) 2002 M. Bakker
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: decode.c,v 1.16 2004/04/03 19:08:37 menno Exp $
** $Id: decode.c,v 1.16 2004/04/03 19:08:37 menno Exp $
**/
// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      18apr13	adapted from libfaad2's decode.c

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "neaacdec.h"
#include "mp4ff.h"
#include "libmp4ad.h"

#define MAX_ERR_MSG 1023

void error_handler(const aac_dec_opt *opt, const char *fmt, ...)
{
	char msgbuf[MAX_ERR_MSG + 1];	// one extra for failsafe terminator
	va_list ap;
	va_start(ap, fmt);
	_vsnprintf(msgbuf, MAX_ERR_MSG, fmt, ap);
	msgbuf[MAX_ERR_MSG] = 0;	// add failsafe terminator
	va_end(ap);
	if (errno != 0)
	{
		int	used = strlen(msgbuf);
		if (used < MAX_ERR_MSG)
		{
			_snprintf(msgbuf + used, MAX_ERR_MSG - used, 
				"%s (%d)", strerror(errno), errno);
		}
		errno = 0;
	}
	opt->on_error(opt->param, msgbuf);
}

int SetDecoderConfig(NeAACDecHandle hDecoder, const aac_dec_opt *opt)
{
    NeAACDecConfigurationPtr config;
    /* Set the default object type and samplerate */
    /* This is useful for RAW AAC files */
    config = NeAACDecGetCurrentConfiguration(hDecoder);
	if (config == NULL) {
        error_handler(opt, "Can't get decoder configuration.\n");
		return 0;
	}
    if (opt->def_srate)
        config->defSampleRate = opt->def_srate;
	if (opt->object_type)
		config->defObjectType = opt->object_type;
    config->outputFormat = opt->output_format;
	config->downMatrix = opt->down_matrix;
    if (!NeAACDecSetConfiguration(hDecoder, config))
	{
        error_handler(opt, "Can't set decoder configuration.\n");
		return 0;
	}
	return 1;	// success
}

#define MAX_CHANNELS 8 /* make this higher to support files with
                          more channels */

/* FAAD file buffering routines */
/* declare buffering variables */
#define DEC_BUFF_VARS \
    int fileread = 0, bytesconsumed = 0; \
    int buffercount = 0, buffer_index = 0; \
    unsigned char *buffer = NULL; \
    unsigned int bytes_in_buffer = 0;

/* initialise buffering */
#define INIT_BUFF(file) \
    fseek(file, 0, SEEK_END); \
    fileread = ftell(file); \
    fseek(file, 0, SEEK_SET); \
    buffer = (unsigned char*)malloc(FAAD_MIN_STREAMSIZE*MAX_CHANNELS); \
    memset(buffer, 0, FAAD_MIN_STREAMSIZE*MAX_CHANNELS); \
    bytes_in_buffer = fread(buffer, 1, FAAD_MIN_STREAMSIZE*MAX_CHANNELS, file);

/* skip bytes in buffer */
#define UPDATE_BUFF_SKIP(bytes) \
    fseek(infile, bytes, SEEK_SET); \
    buffer_index += bytes; \
    buffercount = 0; \
    bytes_in_buffer = fread(buffer, 1, FAAD_MIN_STREAMSIZE*MAX_CHANNELS, infile);

/* update buffer */
#define UPDATE_BUFF_READ \
    if (bytesconsumed > 0) { \
		int k; \
        for (k = 0; k < (FAAD_MIN_STREAMSIZE*MAX_CHANNELS - bytesconsumed); k++) \
            buffer[k] = buffer[k + bytesconsumed]; \
        bytes_in_buffer += fread(buffer + (FAAD_MIN_STREAMSIZE*MAX_CHANNELS) - bytesconsumed, 1, bytesconsumed, infile); \
        bytesconsumed = 0; \
    }

/* update buffer indices after NeAACDecDecode */
#define UPDATE_BUFF_IDX(frame) \
    bytesconsumed += frame.bytesconsumed; \
    buffer_index += frame.bytesconsumed; \
    bytes_in_buffer -= frame.bytesconsumed;

/* true if decoding has to stop because of EOF */
#define IS_FILE_END buffer_index >= fileread

/* end buffering */
#define END_BUFF if (buffer) free(buffer);

int id3v2_tag(unsigned char *buffer)
{
    if (strncmp((const char *)buffer, "ID3", 3) == 0) {
        unsigned long tagsize;

        /* high bit is not used */
        tagsize = (buffer[6] << 21) | (buffer[7] << 14) |
            (buffer[8] <<  7) | (buffer[9] <<  0);

        tagsize += 10;

        return tagsize;
    } else {
        return 0;
    }
}

int decodeAACfile(const char *path, const aac_dec_opt *opt)
{
    int tagsize = 0;
    unsigned long samplerate = 0;
    unsigned char channels = 0;
    void *sample_buffer = NULL;

    FILE *infile = NULL;

    NeAACDecHandle hDecoder = NULL;
    NeAACDecFrameInfo frameInfo = {0};

	int	result = 0;	// assume failure

    /* declare variables for buffering */
    DEC_BUFF_VARS

    infile = fopen(path, "rb");
    if (infile == NULL)
    {
        /* unable to open file */
        error_handler(opt, "Error opening file: %s\n", path);
		goto aac_decode_error;
    }
    INIT_BUFF(infile)

    tagsize = id3v2_tag(buffer);
    if (tagsize)
    {
        UPDATE_BUFF_SKIP(tagsize)
    }

    hDecoder = NeAACDecOpen();
	if (hDecoder == NULL) {
        error_handler(opt, "Can't open decoder.\n");
		goto aac_decode_error;
	}

	if (!SetDecoderConfig(hDecoder, opt)) {
        error_handler(opt, "Can't set decoder configuration.\n");
		goto aac_decode_error;
	}
    if ((bytesconsumed = NeAACDecInit(hDecoder, buffer, bytes_in_buffer,
        &samplerate, &channels)) < 0)
    {
        /* If some error initializing occured, skip the file */
        error_handler(opt, "Error initializing decoder library.\n");
		goto aac_decode_error;
    }
    buffer_index += bytesconsumed;

    do
    {
        /* update buffer */
        UPDATE_BUFF_READ

        sample_buffer = NeAACDecDecode(hDecoder, &frameInfo, buffer, bytes_in_buffer);

        /* update buffer indices */
        UPDATE_BUFF_IDX(frameInfo)

        if (frameInfo.error > 0)
        {
            error_handler(opt, "%s\n", NeAACDecGetErrorMessage(frameInfo.error));
        }

        if ((frameInfo.error == 0) && (frameInfo.samples > 0))
        {
			if (opt->on_output(opt->param, fileread, buffer_index, &frameInfo, sample_buffer))
				goto aac_decode_error;
        }

        if (buffer_index >= fileread)
            sample_buffer = NULL; /* to make sure it stops now */

    } while (sample_buffer != NULL);
	result = 1;	// success

aac_decode_error:
	if (hDecoder != NULL)
		NeAACDecClose(hDecoder);
	if (infile != NULL)
	    fclose(infile);
    END_BUFF

    return result;
}

int GetAACTrack(mp4ff_t *infile)
{
    /* find AAC track */
    int i, rc;
    int numTracks = mp4ff_total_tracks(infile);

    for (i = 0; i < numTracks; i++)
    {
        unsigned char *buff = NULL;
        unsigned int buff_size = 0;
        mp4AudioSpecificConfig mp4ASC;

        mp4ff_get_decoder_config(infile, i, &buff, &buff_size);

        if (buff)
        {
            rc = NeAACDecAudioSpecificConfig(buff, buff_size, &mp4ASC);
            free(buff);

            if (rc < 0)
                continue;
            return i;
        }
    }

    /* can't decode this */
    return -1;
}

uint32_t read_callback(void *user_data, void *buffer, uint32_t length)
{
    return fread(buffer, 1, length, (FILE*)user_data);
}

uint32_t seek_callback(void *user_data, uint64_t position)
{
    return fseek((FILE*)user_data, position, SEEK_SET);
}

int decodeMP4file(const char *path, const aac_dec_opt *opt)
{
    int track = 0;
    unsigned long samplerate = 0;
    unsigned char channels = 0;
    void *sample_buffer = NULL;

    mp4ff_t *infile = NULL;
    FILE *mp4File = NULL;
    int sampleId = 0;
	int	numSamples = 0;

    NeAACDecHandle hDecoder = NULL;
    NeAACDecFrameInfo frameInfo = {0};

    unsigned char *buffer = NULL;
    unsigned int buffer_size = 0;

	int	result = 0;	// assume failure

    /* initialise the callback structure */
    mp4ff_callback_t *mp4cb = malloc(sizeof(mp4ff_callback_t));
	if (mp4cb == NULL) {
        error_handler(opt, "Can't allocate MP4 callback\n", path);
		goto mp4_decode_error;
	}

    mp4File = fopen(path, "rb");
	if (!mp4File) {
        error_handler(opt, "Error opening input file: %s\n", path);
		goto mp4_decode_error;
	}
    mp4cb->read = read_callback;
    mp4cb->seek = seek_callback;
    mp4cb->user_data = mp4File;

    infile = mp4ff_open_read(mp4cb);
    if (!infile)
    {
        /* unable to open file */
        error_handler(opt, "Error opening MP4 file: %s\n", path);
		goto mp4_decode_error;
    }

    if ((track = GetAACTrack(infile)) < 0)
    {
        error_handler(opt, "Unable to find correct AAC sound track in the MP4 file.\n");
		goto mp4_decode_error;
    }

    mp4ff_get_decoder_config(infile, track, &buffer, &buffer_size);

    hDecoder = NeAACDecOpen();
	if (hDecoder == NULL) {
        error_handler(opt, "Can't open decoder.\n");
		goto mp4_decode_error;
	}

 	if (!SetDecoderConfig(hDecoder, opt)) {
        error_handler(opt, "Can't set decoder configuration.\n");
		goto mp4_decode_error;
	}
    if (NeAACDecInit2(hDecoder, buffer, buffer_size, &samplerate, &channels) < 0)
    {
        /* If some error initializing occured, skip the file */
        error_handler(opt, "Error initializing decoder library.\n");
		goto mp4_decode_error;
    }
    if (buffer != NULL) {
        free(buffer);
		buffer = NULL;	// mark buffer free
	}

    numSamples = mp4ff_num_samples(infile, track);

    for (sampleId = 0; sampleId < numSamples; sampleId++)
    {
        int rc;

        rc = mp4ff_read_sample(infile, track, sampleId, &buffer, &buffer_size);
        if (rc == 0)
        {
            error_handler(opt, "Reading from MP4 file failed.\n");
			goto mp4_decode_error;
        }

        sample_buffer = NeAACDecDecode(hDecoder, &frameInfo, buffer, buffer_size);

        if (buffer != NULL) {
            free(buffer);
			buffer = NULL;	// mark buffer free
		}

        if ((frameInfo.error == 0) && (frameInfo.samples > 0))
        {
			if (opt->on_output(opt->param, numSamples, sampleId, &frameInfo, sample_buffer))
				goto mp4_decode_error;
        }

        if (frameInfo.error > 0)
        {
            error_handler(opt, "%s\n", NeAACDecGetErrorMessage(frameInfo.error));
        }
    }
	result = 1;	// success

mp4_decode_error:
	if (hDecoder != NULL)
		NeAACDecClose(hDecoder);
	if (infile != NULL)
		mp4ff_close(infile);
	if (mp4cb != NULL)
		free(mp4cb);
	if (mp4File != NULL)
		fclose(mp4File);
    if (buffer != NULL)
        free(buffer);

    return result;
}

int aac_decode(const char *path, const aac_dec_opt *opt)
{
    int result = 0;
    int def_srate = 0;
    int outfile_set = 0;
    int mp4file = 0;
    unsigned char header[8] = {0};
    FILE *hMP4File = NULL;

    mp4file = 0;
    hMP4File = fopen(path, "rb");
    if (!hMP4File)
    {
        error_handler(opt, "Error opening file: %s\n", path);
        return 0;
    }
    if (fread(header, 1, 8, hMP4File) != 8) {
        error_handler(opt, "Error reading file: %s\n", path);
	    fclose(hMP4File);
        return 0;
	}
    fclose(hMP4File);
    if (header[4] == 'f' && header[5] == 't' && header[6] == 'y' && header[7] == 'p')
        mp4file = 1;

    if (mp4file)
    {
        result = decodeMP4file(path, opt);
    }
    else
    {
        result = decodeAACfile(path, opt);
    }

    return result;	// non-zero if success
}
