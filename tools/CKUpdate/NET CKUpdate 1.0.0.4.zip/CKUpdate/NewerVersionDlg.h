#if !defined(AFX_NEWERVERSIONDLG_H__6899945A_F29A_4A3C_8505_119A8004D515__INCLUDED_)
#define AFX_NEWERVERSIONDLG_H__6899945A_F29A_4A3C_8505_119A8004D515__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewerVersionDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewerVersionDlg dialog

class CNewerVersionDlg : public CDialog
{
// Construction
public:
	CNewerVersionDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewerVersionDlg)
	enum { IDD = IDD_NEWER_VERSON };
	CStatic	m_Icon;
	CString	m_Prompt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewerVersionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewerVersionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnYes();
	afx_msg void OnNo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWERVERSIONDLG_H__6899945A_F29A_4A3C_8505_119A8004D515__INCLUDED_)
