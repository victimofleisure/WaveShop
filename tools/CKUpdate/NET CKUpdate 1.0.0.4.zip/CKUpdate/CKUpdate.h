// Copyleft 2013 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      26jan13	initial version

		check for updates DLL
 
*/

// CKUpdate.h : main header file for the CKUPDATE DLL
//

#if !defined(AFX_CKUPDATE_H__AC60B2FE_F792_4882_8367_EB8B883C4A17__INCLUDED_)
#define AFX_CKUPDATE_H__AC60B2FE_F792_4882_8367_EB8B883C4A17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCKUpdateApp
// See CKUpdate.cpp for the implementation of this class
//

#include "WinAppEx.h"

class CCKUpdateApp : public CWinAppEx
{
public:
	CCKUpdateApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCKUpdateApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CCKUpdateApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	friend UINT PASCAL EXPORT CKUpdate(HWND ParentWnd, LPCTSTR TargetAppName, UINT Flags);
};

extern CCKUpdateApp theApp;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CKUPDATE_H__AC60B2FE_F792_4882_8367_EB8B883C4A17__INCLUDED_)
