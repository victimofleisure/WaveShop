// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      23jan12	initial version
        01      26jan13	refactor
        02      27jan13	prevent reentrance
        03      31jan13	add support for portable build

        check for updates
 
*/

#include "stdafx.h"
#include "CKUpdate.h"
#include "UpdateCheck.h"
#include "HttpDownload.h"
#include "PathStr.h"
#include "Minizip.h"
#include "VersionInfo.h"
#include "NewerVersionDlg.h"
#include "ProgressDlg.h"
#include <afxmt.h>

#define DOWNLOAD_PAGE_URL	_T("http://%s.sourceforge.net/download.html")
#define BUILD_REGULAR		_T("bin")
#define BUILD_PORTABLE		_T("portable")
#define PLATFORM_X64		_T("-x64")
#define POSTFIX_FORMAT		_T("%s%s.zip")
#define INSTALLER_NAME		_T("%s.msi")
#define RK_UPDATE_DECLINED	_T("UpdateDeclined")

class CProgressHttpDownload : public CHttpDownload
{
public:
	CProgressHttpDownload(CWnd *ParentWnd);
	bool	GetHttpDownload(LPCTSTR DownloadURL, LPCTSTR DestPath, DWORD& TotalRcvd);
	virtual	bool	OnDownloadProgress(UINT FileSize, UINT BytesRcvd);

protected:
	CWnd	*m_ParentWnd;
	CProgressDlg	m_ProgressDlg;
};

CProgressHttpDownload::CProgressHttpDownload(CWnd *ParentWnd)
{
	m_ParentWnd = ParentWnd;
}

bool CProgressHttpDownload::GetHttpDownload(LPCTSTR DownloadURL, LPCTSTR DestPath, DWORD& TotalRcvd)
{
	CWaitCursor	wc;
	bool	retc = CHttpDownload::GetHttpDownload(DownloadURL, DestPath, TotalRcvd);
	if (!retc)
		DeleteFile(DestPath);
	return(retc);
}

bool CProgressHttpDownload::OnDownloadProgress(UINT FileSize, UINT TotalRcvd)
{
	if (m_ProgressDlg.m_hWnd == NULL) {
		m_ProgressDlg.Create(m_ParentWnd);
		m_ProgressDlg.SetRange(0, FileSize);
	}
	m_ProgressDlg.SetPos(TotalRcvd);
	if (m_ProgressDlg.Canceled()) {
		m_ProgressDlg.DestroyWindow();
		return(FALSE);
	}
	return(TRUE);
}

CUpdateCheck::CUpdateCheck(HWND ParentWnd, LPCTSTR TargetAppName, UINT Flags)
{
	m_ParentWnd = ParentWnd;
	m_TargetAppName = TargetAppName;
	m_Flags = Flags;
	m_DownloadVersion.QuadPart = 0;
	m_CurrentVersion.QuadPart = 0;
}

bool CUpdateCheck::Update()
{
	CMutex	mutex(FALSE, m_TargetAppName + _T("CKUpdateMutex"));
	CSingleLock	lock(&mutex);	// prevent reentrance
	if (!lock.Lock(0)) {	// try to acquire mutex, no wait
		if (m_Flags & UF_EXPLICIT) {	// if explicit check
			CString	msg;
			msg.Format(IDS_UPCK_ALREADY_RUNNING);
			CKMessageBox(msg);
		}
		return(FALSE);
	}
	if (!GetDownloadURL())	// get download URL
		return(FALSE);
	if (!UpgradePrompt())	// if upgrade available, prompt user
		return(FALSE);
	if (!Download())	// download installer package
		return(FALSE);
	if (!Reinstall())	// reinstall target app
		return(FALSE);
	return(TRUE);	// success
}

bool CUpdateCheck::GetDownloadURL()
{
	CString	msg;
	CPathStr	TargetAppPath(theApp.GetAppFolder());
	TargetAppPath.Append(CString(m_TargetAppName) + _T(".exe"));
	VS_FIXEDFILEINFO	AppInfo;
	if (!CVersionInfo::GetFileInfo(AppInfo, TargetAppPath)) {
		if (m_Flags & UF_EXPLICIT) {	// if explicit check
			msg.Format(IDS_UPCK_CANT_GET_VERSION_INFO, m_TargetAppName);
			CKMessageBox(msg);
		}
		return(FALSE);
	}
	m_CurrentVersion.LowPart = AppInfo.dwFileVersionLS;
	m_CurrentVersion.HighPart = AppInfo.dwFileVersionMS;
	CString	PageURL;
	PageURL.Format(DOWNLOAD_PAGE_URL, m_TargetAppName);
	PageURL.MakeLower();
	CString	VersionPrefix(m_TargetAppName);
	VersionPrefix.MakeLower();
	CHttpDownload	httpdl;
	LPCTSTR	BuildTag, PlatformTag;
	if (m_Flags & UF_PORTABLE)	// if target application is portable
		BuildTag = BUILD_PORTABLE;
	else	// normal build
		BuildTag = BUILD_REGULAR;
	if (m_Flags & UF_X64)	// if target application is 64-bit
		PlatformTag = PLATFORM_X64;
	else	// 32-bit platform
		PlatformTag = _T("");
	CString	VersionPostfix;
	VersionPostfix.Format(POSTFIX_FORMAT, BuildTag, PlatformTag);
	// download specified download page and parse it for download URL
	bool	GotURL = httpdl.GetDownloadURL(PageURL, 
		VersionPrefix, VersionPostfix, m_DownloadVersion, m_DownloadURL);
	if (!GotURL) {
		if (m_Flags & UF_EXPLICIT) {	// if explicit check
			msg.Format(IDS_UPCK_CANT_GET_URL, httpdl.GetErrorMessage(), PageURL);
			CKMessageBox(msg);
		}
		return(FALSE);
	}
	return(TRUE);
}

bool CUpdateCheck::UpgradePrompt()
{
	CString	msg;
	if (m_CurrentVersion.QuadPart < m_DownloadVersion.QuadPart) {	// if newer version
		if (!(m_Flags & UF_EXPLICIT)) {	// if automatic check
			ULONGLONG	DeclinedVersion = 0;
			if (theApp.RdRegStruct(RK_UPDATE_DECLINED, DeclinedVersion, DeclinedVersion)) {
				// if this update was previously declined according to registry
				if (DeclinedVersion == m_DownloadVersion.QuadPart)
					return(FALSE);	// quietly suppress notification
			}
		}
		msg.Format(IDS_UPCK_WANT_NEWER_VERSION, m_TargetAppName,
			HIWORD(m_CurrentVersion.HighPart), LOWORD(m_CurrentVersion.HighPart),
			HIWORD(m_CurrentVersion.LowPart), LOWORD(m_CurrentVersion.LowPart),
			HIWORD(m_DownloadVersion.HighPart), LOWORD(m_DownloadVersion.HighPart),
			HIWORD(m_DownloadVersion.LowPart), LOWORD(m_DownloadVersion.LowPart));
		if (m_Flags & UF_EXPLICIT) {	// if explicit check
			UINT	nType = MB_YESNO | MB_APPLMODAL | MB_ICONQUESTION;
			if (CKMessageBox(msg, nType) != IDYES)	// if update unwanted
				return(FALSE);
		} else {	// automatic check
			CNewerVersionDlg	dlg(CWnd::FromHandle(m_ParentWnd));
			dlg.m_Prompt = msg;
			W64INT	retc = dlg.DoModal();
			if (retc == IDNO) {	// if update declined
				// save declined update's version number in registry
				theApp.WrRegStruct(RK_UPDATE_DECLINED, m_DownloadVersion.QuadPart);
			}
			if (retc != IDYES)
				return(FALSE);
		}
	} else {	// already have latest version
		if (m_Flags & UF_EXPLICIT) {	// if explicit check
			msg.Format(IDS_UPCK_HAVE_LATEST_VERSION, m_TargetAppName);
			CKMessageBox(msg, MB_ICONINFORMATION);
		}
		return(FALSE);
	}
	return(TRUE);
}

bool CUpdateCheck::Download()
{
	// get temp file name for download
	CString	msg;
	DWORD	TotalRcvd;
	CString	DownloadPath;
	if (!theApp.GetTempFileName(DownloadPath, _T("cku"), 0)) {
		CKMessageBox(IDS_UPCK_CANT_GET_TEMP_FILE);
		return(FALSE);
	}
	// download zip file
	CProgressHttpDownload	httpdl(CWnd::FromHandle(m_ParentWnd));
	CWaitCursor	wc;
	if (!httpdl.GetHttpDownload(m_DownloadURL, DownloadPath, TotalRcvd)) {
		DeleteFile(DownloadPath);	// delete partial download if any
		msg.Format(IDS_UPCK_CANT_DOWNLOAD_FILE, httpdl.GetErrorMessage(), m_DownloadURL);
		CKMessageBox(msg);
		return(FALSE);
	}
	// create installer path
	CPathStr	InstPath;
	theApp.GetTempPath(InstPath);
	CString	InstName;
	if (m_Flags & UF_PORTABLE) {	// if target application is portable
		InstPath.Append(m_TargetAppName);	// extract all files to subfolder
		CString	sTicks;
		sTicks.Format(_T("-%x"), GetTickCount());
		InstPath += sTicks;	// append tick count to folder name for uniqueness
		if (!CreateDirectory(InstPath, NULL)) {	// if can't create directory
			DeleteFile(DownloadPath);	// delete download
			msg.Format(IDS_UPCK_CANT_CREATE_DIR, InstPath);
			CKMessageBox(msg);
			return(FALSE);
		}
	} else {	// normal build with installer
		InstName.Format(INSTALLER_NAME, m_TargetAppName);
		InstPath.Append(InstName);	// make installer path
	}
	// extract file(s) from downloaded zip file
	bool	UnzipOK;
	{
		CMinizip	zip;
		UnzipOK = zip.Open(DownloadPath);
		if (UnzipOK) {
			if (m_Flags & UF_PORTABLE) {	// if target application is portable
				UnzipOK = zip.ExtractAll(InstPath);	// extract all files
			} else
				UnzipOK = zip.Extract(InstName, InstPath);	// extract installer
		}
	}
	DeleteFile(DownloadPath);	// delete download regardless
	if (!UnzipOK) {
		msg.Format(IDS_UPCK_CANT_UNZIP_DOWNLOAD, DownloadPath);
		CKMessageBox(msg);
		return(FALSE);
	}
	m_InstallerPath = InstPath;
	return(TRUE);
}

BOOL CALLBACK CUpdateCheck::EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	CString	s;
	int	MAXLEN = 32;
	LPTSTR	p = s.GetBuffer(MAXLEN);
	GetWindowText(hwnd, p, MAXLEN);
	s.ReleaseBuffer();
	LPCTSTR	Target = LPCTSTR(lParam);
	if (s.Find(Target) == 0) {
		SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		PostMessage(hwnd, WM_CLOSE, 0, 0);
	}
	return(TRUE);
}

bool CUpdateCheck::Reinstall()
{
	enum {
		INITIAL_DELAY = 1,	// approximate initial delay in seconds
		PING_COUNT = INITIAL_DELAY + 1,	// first ping doesn't count
	};
	CString	msg;
	// verify reinstall script exists, because ShellExecute won't care
	LPCTSTR	ScriptName = _T("reinstall.bat");
	CPathStr	ScriptPath(theApp.GetAppFolder());
	ScriptPath.Append(ScriptName);
	if (!PathFileExists(ScriptPath)) {
		msg.Format(IDS_UPCK_SCRIPT_NOT_FOUND, ScriptPath);	// shouldn't happen
		CKMessageBox(msg);
		return(FALSE);
	}
	// launch reinstall script
	CString	CmdLine;
	CmdLine.Format(_T("/c %s %d \"%s\" %s"), ScriptName, 
		PING_COUNT, m_InstallerPath, m_TargetAppName);
	int	ShellRet = int(ShellExecute(NULL, NULL, 
		_T("cmd"), CmdLine, theApp.GetAppFolder(), SW_SHOW));
	if (ShellRet <= 32) {	// if ShellExecute failed
		msg.Format(IDS_UPCK_CANT_RUN_INSTALLER, ShellRet);
		CKMessageBox(msg);
		return(FALSE);
	}
	LPCTSTR	TargetAppName = m_TargetAppName;
	EnumWindows(EnumWindowsProc, LPARAM(TargetAppName));
	return(TRUE);
}

int CUpdateCheck::CKMessageBox(LPCTSTR lpszText, UINT nType)
{
	return(::MessageBox(m_ParentWnd, lpszText, m_TargetAppName, nType));
}

int CUpdateCheck::CKMessageBox(UINT nIDPrompt, UINT nType)
{
	CString	msg((LPCTSTR)nIDPrompt);
	return(CKMessageBox(msg, nType));
}
