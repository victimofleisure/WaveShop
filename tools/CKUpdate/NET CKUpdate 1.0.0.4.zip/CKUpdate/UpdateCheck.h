// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      23jan12	initial version
        02      26jan13	refactor
        03      31jan13	add support for portable build

        check for updates
 
*/

#ifndef CUPDATECHECK_INCLUDED
#define CUPDATECHECK_INCLUDED

class CUpdateCheck : public WObject {
public:
// Construction
	CUpdateCheck(HWND ParentWnd, LPCTSTR TargetAppName, UINT Flags);

// Constants
	enum {	// update flags
		UF_EXPLICIT	= 0x01,	// explicit check (as opposed to automatic)
		UF_X64		= 0x02,	// target application is 64-bit
		UF_PORTABLE	= 0x04,	// target application is portable (no installer)
	};

// Operations
	bool	Update();

protected:
// Data members
	HWND	m_ParentWnd;		// parent window for dialogs and message boxes
	CString	m_TargetAppName;	// name of application to be updated
	UINT	m_Flags;			// update flags; see enum above
	CString	m_DownloadURL;		// download URL parsed from home page
	ULARGE_INTEGER	m_CurrentVersion;	// current version number
	ULARGE_INTEGER	m_DownloadVersion;	// version available for download
	CString	m_InstallerPath;	// path to installer package

// Helpers
	bool	GetDownloadURL();
	bool	UpgradePrompt();
	bool	Download();
	bool	Reinstall();
	static	BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
	int		CKMessageBox(LPCTSTR lpszText, UINT nType = MB_OK);
	int		CKMessageBox(UINT nIDPrompt, UINT nType = MB_OK);
};

#endif
