// NewerVersionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CKUpdate.h"
#include "NewerVersionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewerVersionDlg dialog


CNewerVersionDlg::CNewerVersionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewerVersionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewerVersionDlg)
	m_Prompt = _T("");
	//}}AFX_DATA_INIT
}


void CNewerVersionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewerVersionDlg)
	DDX_Control(pDX, IDC_NV_ICON, m_Icon);
	DDX_Text(pDX, IDC_NV_PROMPT, m_Prompt);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewerVersionDlg, CDialog)
	//{{AFX_MSG_MAP(CNewerVersionDlg)
	ON_BN_CLICKED(IDYES, OnYes)
	ON_BN_CLICKED(IDNO, OnNo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewerVersionDlg message handlers

BOOL CNewerVersionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_Icon.SetIcon(LoadIcon(NULL, IDI_QUESTION));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewerVersionDlg::OnYes() 
{
	EndDialog(IDYES);
}

void CNewerVersionDlg::OnNo() 
{
	EndDialog(IDNO);
}

