//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CKUpdate.rc
//
#define IDD_NEWER_VERSON                101
#define IDD_PROGRESS                    102
#define IDS_UPCK_ALREADY_RUNNING        200
#define IDS_UPCK_CANT_CREATE_DIR        201
#define IDS_UPCK_CANT_DOWNLOAD_FILE     202
#define IDS_UPCK_CANT_GET_TEMP_FILE     203
#define IDS_UPCK_CANT_GET_URL           204
#define IDS_UPCK_CANT_GET_VERSION       205
#define IDS_UPCK_CANT_GET_VERSION_INFO  206
#define IDS_UPCK_CANT_RUN_INSTALLER     207
#define IDS_UPCK_CANT_UNZIP_DOWNLOAD    208
#define IDS_UPCK_DOWNLOADING            209
#define IDS_UPCK_HAVE_LATEST_VERSION    210
#define IDS_UPCK_SCRIPT_NOT_FOUND       211
#define IDS_UPCK_UPDATE_CANCELED        212
#define IDS_UPCK_WANT_NEWER_VERSION     213
#define IDC_NV_ICON                     1001
#define IDC_NV_PROMPT                   1002
#define IDC_PROGRESS                    1003
#define IDC_PROGRESS_PERCENT            1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        214
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
