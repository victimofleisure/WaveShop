/*
 * libid3tag - ID3 tag manipulation library
 * Copyright (C) 2000-2004 Underbit Technologies, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: id3tag.c,v 1.9 2013/07/31 21:51:32 ck Exp $
 */

// ck 31jul13 added to allow DLL usage
//
// Some id3tag functions allocate an object on the heap and rely on the
// caller to free the object; examples include id3_ucs4_latin1duplicate
// and similar functions. In a DLL version of id3tag, such objects MUST
// be freed using id3_free instead of free, otherwise the heap may be
// corrupted, potentially crashing the application. 
//
// This function is a custom extension of id3tag, to facilitate porting
// it to a DLL. DLLs should free any memory they allocate, and if these
// allocations are exposed to the user, the DLL should provide a method
// for freeing them, so that freeing is done by the DLL's heap manager.
// 
void id3_free(void *data)
{
	free(data);	// DLLs must free their own memory
}
