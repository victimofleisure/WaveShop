// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      25apr13	initial version

		DirectSound capture test
 
*/

// DSCaptureTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DSCaptureTest.h"
#include "conio.h"
#include "Prompt.h"
#include <math.h>
#include "CoInitializer.h"
#include "dxerr8.h"	// for DX error strings

using namespace CPrompt;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

CDSCaptureTest::CDSCaptureTest()
{
}

CDSCaptureTest::~CDSCaptureTest()
{
}

bool CDSCaptureTest::GetDeviceInfo()
{
	if (!CDSCapture::EnumDevices(m_DevInfo))
		return(FALSE);
	int	devs = m_DevInfo.GetSize();
	_tprintf(_T("%d DirectSound devices found\n"), devs);
	for (int iDev = 0; iDev < devs; iDev++)
		_tprintf(_T("[%d] %s\n"), iDev, m_DevInfo[iDev].m_Description);
	return(TRUE);
}

void CDSCaptureTest::CMyDSCapture::OnDXError(HRESULT hr) const
{
	_tprintf(_T("%s: %s\n"), DXGetErrorString8(hr), DXGetErrorDescription8(hr));
}

int CDSCaptureTest::TrimTrailingZeros(CString& Str)
{
	int	len = Str.GetLength();
	if (len) {
		LPCTSTR	pStr = Str.GetBuffer(0);
		int	iPos = len - 1;
		while (iPos >= 0 && pStr[iPos] == '0')
			iPos--;
		len = iPos + 1;
		Str.ReleaseBuffer(len);
	}
	return(len);
}

CString CDSCaptureTest::FrameToTime(W64INT Frame, int Precision) const
{
	UINT	SampleRate = m_Wave.GetSampleRate();
	int	Ticks = Frame % SampleRate;
	W64INT	TimeSecs = Frame / SampleRate;
	int	seconds = int(TimeSecs % 60);
	TimeSecs /= 60;
	int	minutes = int(TimeSecs % 60);
	int	hours = int(TimeSecs / 60);
	CString	sResult, sFracSec;
	sResult.Format(_T("%d:%02d:%02d"), hours, minutes, seconds);
	double	FracSec = double(Ticks) / SampleRate;
	if (Precision < 0)
		sFracSec.Format(_T("%f"), FracSec);
	else
		sFracSec.Format(_T("%.*f"), Precision, FracSec);
	if (Precision >= 0 || TrimTrailingZeros(sFracSec) > 2)
		sResult += sFracSec.Mid(1);
	return(sResult);
}

bool CDSCaptureTest::TimeToFrame(LPCTSTR Time, W64INT& Frame) const
{
	CString	sTime(Time);
	sTime.Replace(':', ' ');	// allow spaces instead of colons
	int	hours = 0, mins = 0, secs = 0;
	double	ticks = 0;
	if (_stscanf(sTime, _T("%d%d%d%lf"), &hours, &mins, &secs, &ticks) < 1)
		return(FALSE);
	UINT	SampleRate = m_Wave.GetSampleRate();
	Frame = W64INT(hours * 3600 + mins * 60 + secs) * SampleRate 
		+ round(ticks * SampleRate);
	return(TRUE);
}

bool CDSCaptureTest::GetFrameTime(LPCTSTR Prompt, W64INT& Frame)
{
	CString	sTime(FrameToTime(Frame));
	if (!GetVal(Prompt, sTime))
		return(FALSE);
	return(TimeToFrame(sTime, Frame));
}

void CDSCaptureTest::PromptCmd()
{
	static const LPCSTR Help =
		"q  quit\n";
	bool	more = TRUE;
	bool	ShowHelp = TRUE;
	while (more) {
		if (ShowHelp) {
			fputs(Help, stdout);
			ShowHelp = FALSE;
		}
		fputs("DSCapture> ", stdout);
		int	key = _getch();
		printf("%c\n", key);
		switch (key) {
		case 'q':	// quit
			more = FALSE;
			break;
		default:
			ShowHelp = TRUE;
		}
	}
}

void CDSCaptureTest::NatterMain()
{
	const UINT UpdatePeriod = 50;	// natter period, in milliseconds
	while (m_Natter.WaitForStart()) {
		while (!m_Natter.GetStopFlag()) {
			Sleep(UpdatePeriod);
		}
	}
}

UINT CDSCaptureTest::NatterFunc(LPVOID pParam)
{
	CDSCaptureTest	*pTest = (CDSCaptureTest *)pParam;
	pTest->NatterMain();
	return(0);
}

bool CDSCaptureTest::MainTest(LPCTSTR Path)
{
	try {
		CCoInitializer	coninit;	// initialize COM
		TRY {
			// create natter thread
			if (!m_Natter.Create(NatterFunc, this, 0, 0, INFINITE))
				return(FALSE);
			if (!m_Natter.Run(TRUE))	// start natter thread running
				return(FALSE);
			if (!GetDeviceInfo()) {	// find DirectSound devices
				_tprintf(_T("can't enumerate DirectSound devices\n"));
				return(FALSE);
			}
			if (!m_DevInfo.GetSize())
				return(FALSE);	// no devices found
			int	iDev = 0;
			_tprintf(_T("using device '%s'\n"), m_DevInfo[iDev].m_Description);
			// create player
			HWND	hWnd = GetDesktopWindow();
			if (!m_Capture.Create(NULL, &m_DevInfo[iDev].m_Guid)) {
				_tprintf(_T("can't create capture\n"));
				return(FALSE);
			}
			if (!m_Capture.Open("test.wav", 2, 44100, 16)) {
				_tprintf(_T("can't open capture\n"));
				return(FALSE);
			}
			if (!m_Capture.Start()) {
				_tprintf(_T("can't start capture\n"));
				return(FALSE);
			}
			PromptCmd();	// prompt user for commands
			m_Capture.Destroy();	// before dtor, else derived OnDXError not called
		}
		CATCH (CException, e) {
			e->ReportError();
			return(FALSE);
		}
		END_CATCH
	}
	catch (HRESULT) {
		_tprintf("can't initialize COM\n");
		return(FALSE);
	}
	return(TRUE);
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		return 1;
	}
	LPCTSTR	Path = argv[1];
		Path = _T("C:\\temp\\wav\\01ThisIsCheese.wav");
//		Path = _T("C:\\temp\\wav\\Chicago IX (Greatest Hits)\\11 Beginnings.wav");
//		Path = _T("C:\\temp\\wav\\Chris Korda & The Church of Euthanasia - Six Billion Humans Can't Be Wrong\\Chris Korda & The Church of Euthanasia - Six Billion Humans Can't Be Wrong.wav");
//		Path = _T("C:\\temp\\wav\\test\\Error.wav");
//		Path = _T("C:\\temp\\wav\\test\\60hz44k16b.wav");
//		Path = _T("C:\\temp\\wav\\test\\440hz44k16b 10s shaped.wav");
	CDSCaptureTest	test;
	if (!test.MainTest(Path))
		_tprintf(_T("FAIL\n"));
	return 0;
}
