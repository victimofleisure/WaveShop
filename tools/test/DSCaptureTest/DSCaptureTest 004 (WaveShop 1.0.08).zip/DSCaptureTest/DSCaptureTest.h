// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      25apr13	initial version

		DirectSound capture test
 
*/

#if !defined(AFX_DSCAPTURETEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_)
#define AFX_DSCAPTURETEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include "DSCapture.h"
#include "Wave.h"

class CDSCaptureTest : public WObject {
public:
// Construction
	CDSCaptureTest();
	~CDSCaptureTest();

// Operations
	bool	MainTest(LPCTSTR Path);

protected:
// Types
	class CMyDSCapture : public CDSCapture {
	protected:
		virtual	void	OnDXError(HRESULT hr) const;
	};

// Member data
	CDSPlayer::CDSDeviceInfoArray	m_DevInfo;	// DirectShow device info
	// declare wave BEFORE player to ensure wave outlives player
	CWave	m_Wave;				// wave to play
	CMyDSCapture	m_Capture;	// DirectSound capture
	CString	m_CurTime;			// play time as a string
	CString	m_WavePath;			// wave path
	CWorkerThread	m_Natter;	// worker thread to natter current position

// Helpers
	bool	GetDeviceInfo();
	void	PromptCmd();
	static	int		TrimTrailingZeros(CString& Str);
	double	FrameToNormPos(W64INT Frame) const;
	W64INT	NormPosToFrame(double NormPos) const;
	CString	FrameToTime(W64INT Frame, int Precision = -1) const;
	bool	TimeToFrame(LPCTSTR Time, W64INT& Frame) const;
	bool	GetFrameTime(LPCTSTR Prompt, W64INT& Frame);
	void	NatterMain();
	static	UINT	NatterFunc(LPVOID pParam);
};

#endif // !defined(AFX_DSCAPTURETEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_)
