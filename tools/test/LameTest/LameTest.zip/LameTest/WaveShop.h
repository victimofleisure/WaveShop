#ifndef CWAVESHOPAPP_INCLUDED
#define CWAVESHOPAPP_INCLUDED

#include "Resource.h"

class CDLLWrap;

class CWaveShopApp : public CWinApp {
public:
	CString GetAppPath();
	CString GetAppFolder();
	static	bool	GetDLLFunctions(CDLLWrap& Lib, LPCTSTR LibPath, const int *OrdinalTbl, int Functions, CPtrArray& FuncPtr);
};

extern CWaveShopApp theApp;

#endif
