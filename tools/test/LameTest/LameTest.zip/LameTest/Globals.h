// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00		08mar10	initial version
        01		04oct12	move rounding to its own file
        02		13oct12	add W64ULONG
		03		01dec12	add W64 dynamic casts
		04		29dec12	move x64 wrappers to their own file
		05		24jan13	disable undo natter
		06		25feb13	move app-specific stuff to end
        07      27feb13	add MPEG filter

		global definitions and inlines

*/

#pragma once

#pragma warning(disable : 4100)	// unreferenced formal parameter

// minimal base for non-CObject classes
#include "WObject.h"

// registry strings
#define REG_SETTINGS		_T("Settings")

// key status bits for GetKeyState and GetAsyncKeyState
#define GKS_TOGGLED			0x0001
#define GKS_DOWN			0x8000

// trig macros
#define PI 3.141592653589793
#define DTR(x) (x * PI / 180)	// degrees to radians
#define RTD(x) (x * 180 / PI)	// radians to degrees

// clamp a value to a range
#define CLAMP(x, lo, hi) (min(max((x), (lo)), (hi)))

// trap bogus default case in switch statement
#define NODEFAULTCASE	ASSERT(0)

// load string from resource via temporary object
#define LDS(x) CString((LPCTSTR)x)

#if _MFC_VER < 0x0800
// calculate number of elements in a fixed-size array
#define _countof(arr) (sizeof(arr) / sizeof(arr[0]))
#endif

// atof's generic-text wrapper is missing in MFC 6
#ifndef _tstof
#ifdef UNICODE
#define _tstof(x) _tcstod(x, NULL)
#else
#define _tstof(x) atof(x)
#endif
#endif

#if _MFC_VER < 0x0800
#define genericException generic	// generic was deprecated in .NET 2005
#endif

inline void StoreBool(CArchive& ar, bool flag)
{
#if _MFC_VER >= 0x0700
	ar << flag;
#else	// MFC 6 CArchive doesn't support bool
	BYTE	byte = flag;
	ar << byte;
#endif
}

inline void LoadBool(CArchive& ar, bool& flag)
{
#if _MFC_VER >= 0x0700
	ar >> flag;
#else	// MFC 6 CArchive doesn't support bool
	BYTE	byte;
	ar >> byte;
	flag = byte != 0;
#endif
}

#if _MSC_VER < 1300
#define ACTIVATEAPPTASK HTASK
#else
#define ACTIVATEAPPTASK DWORD
#endif

// x64 wrappers
#include "Wrapx64.h"

// optimized rounding and truncation
#include "Round.h"

#if _MFC_VER > 0x0600
// suppress spurious level 4 warning on ceil function
#pragma warning (push)
#pragma warning (disable: 4985)	// attributes not present on previous declaration.
#include <math.h>
#pragma warning (pop)
#endif

// app-specific globals
