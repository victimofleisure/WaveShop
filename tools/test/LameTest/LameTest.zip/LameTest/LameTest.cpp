// LameTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveShop.h"
#include "Wave.h"
#include "LameWrap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWaveShopApp theApp;

bool test()
{
	CWave	wave;
	LPCTSTR	Path = "C:\\temp\\wav\\01ThisIsCheese.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\Nums_5dot1_24_48000.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k16b 10s.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k16b 10s mono.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k24b 10s.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k32b 10s.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k24b 10s mono.wav";
//	LPCTSTR	Path = "C:\\temp\\wav\\test\\DANGEROUS\\60hz44k32b 10s mono.wav";
	if (!wave.SafeRead(Path)) {
		printf("open fail\n");
		return(FALSE);
	}
	CLameWrap	lame;
	if (!lame.Create(_T("libmp3lame.dll"))) {
		printf("lame create fail\n");
		return(FALSE);
	}
	CLameWrap::ENCODING_PARAMS	params;
	params.AlgorithmQuality = 2;
//	params.BitRateMode = CLameWrap::BRM_CONSTANT;
//	params.BitRateMode = CLameWrap::BRM_AVERAGE;
	params.BitRateMode = CLameWrap::BRM_VARIABLE;
	params.TargetBitRate = 192;
	params.TargetQuality = 0;
	if (!lame.Write("test.mp3", wave, params)) {
		printf("lame write fail\n");
		return(FALSE);
	}
	return(TRUE);
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		printf("Fatal Error: MFC initialization failed\n");
		nRetCode = 1;
	}
	else
	{
		test();
	}

	return nRetCode;
}
