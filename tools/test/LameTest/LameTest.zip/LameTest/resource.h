//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LameTest.rc
//
#define IDD_PROGRESS                    101
#define IDD_PROGRESS_DUAL               102
#define IDD_PROGRESS_SLAVE              103
#define IDS_CKUP_CANT_LOAD_DLL          200
#define IDS_DLL_CANT_GET_FUNCTION       201
#define IDS_DOC_ENCODING                202
#define IDS_LAME_ERR_ENCODE             203
#define IDS_LAME_ERR_ENC_BUFFER_SIZE    204
#define IDS_LAME_ERR_ENC_INIT_PARAMS    205
#define IDS_LAME_ERR_ENC_MALLOC         206
#define IDS_LAME_ERR_ENC_PSYCHO         207
#define IDS_LAME_ERR_INIT               208
#define IDS_LAME_ERR_INIT_PARAMS        209
#define IDS_LAME_ERR_SET_AVG_BIT_RATE   210
#define IDS_LAME_ERR_SET_BIT_RATE       211
#define IDS_LAME_ERR_SET_ENC_QUALITY    212
#define IDS_LAME_ERR_SET_NUM_CHANNELS   213
#define IDS_LAME_ERR_SET_NUM_SAMPLES    214
#define IDS_LAME_ERR_SET_SAMPLE_RATE    215
#define IDS_LAME_ERR_SET_VBR_MODE       216
#define IDS_LAME_ERR_SET_VBR_QUALITY    217
#define IDS_WAVE_ERR_BAD_BIT_COUNT      218
#define IDS_WAVE_ERR_BAD_BLOCK_ALIGN    219
#define IDS_WAVE_ERR_BAD_CHANNEL_COUNT  220
#define IDS_WAVE_ERR_BAD_FORMAT_SIZE    221
#define IDS_WAVE_ERR_BAD_SAMPLE_RATE    222
#define IDS_WAVE_ERR_END_OF_FILE        223
#define IDS_WAVE_ERR_NOT_RIFF           224
#define IDS_WAVE_ERR_NOT_WAVE           225
#define IDS_WAVE_ERR_NO_DATA_CHUNK      226
#define IDS_WAVE_ERR_NO_FORMAT_CHUNK    227
#define IDS_WAVE_ERR_UNKNOWN_FORMAT     228
#define IDC_PROGRESS                    1001
#define IDC_PROGRESS_PERCENT            1002
#define IDC_PROGRESS_SUBCAPTION         1003
#define IDC_PROGRESS_SUBPROGRESS        1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        229
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
