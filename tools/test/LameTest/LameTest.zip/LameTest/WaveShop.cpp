#include "stdafx.h"
#include "WaveShop.h"
#include "PathStr.h"
#include "DllWrap.h"

CString CWaveShopApp::GetAppPath()
{
	CString	s = GetCommandLine();
	s.TrimLeft();	// trim leading whitespace just in case
	if (s[0] == '"')	// if first char is a quote
		s = s.Mid(1).SpanExcluding(_T("\""));	// span to next quote
	else
		s = s.SpanExcluding(_T(" \t"));	// span to next whitespace
	return(s);
}

CString CWaveShopApp::GetAppFolder()
{
	CPathStr	path(GetAppPath());
	path.RemoveFileSpec();
	return(path);
}

bool CWaveShopApp::GetDLLFunctions(CDLLWrap& Lib, LPCTSTR LibPath, const int *OrdinalTbl, int Functions, CPtrArray& FuncPtr)
{
	CString	msg;
	if (!Lib.LoadLibrary(LibPath)) {
		msg.Format(IDS_CKUP_CANT_LOAD_DLL, LibPath, GetLastError());
		AfxMessageBox(msg);
		return(FALSE);
	}
	FuncPtr.SetSize(Functions);
	for (int iFunc = 0; iFunc < Functions; iFunc++) {	// for each function
		int	ordinal = OrdinalTbl[iFunc];
		LPVOID	pFunc = Lib.GetProcAddress((LPCTSTR)ordinal);
		if (pFunc == NULL) {	// if we can't get address
			msg.Format(IDS_DLL_CANT_GET_FUNCTION, ordinal, LibPath, GetLastError());
			AfxMessageBox(msg);
			return(FALSE);
		}
		FuncPtr[iFunc] = pFunc;	// store function address in array
	}
	return(TRUE);
}
