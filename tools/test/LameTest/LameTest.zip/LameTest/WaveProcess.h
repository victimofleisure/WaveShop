// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04dec12	initial version
        01      25jan13	add FindSample
        02      25feb13	add Resample
        03      02mar13	move speaker names to base class
		04		04mar13	in FindClipping, add clipping level
		05		20mar13	add GetSpectrum

		wave processing
 
*/

#ifndef CWAVEPROCESS_INCLUDED
#define CWAVEPROCESS_INCLUDED

#include "Wave.h"
#include "ArrayEx.h"

class CWaveProcess : public CWave {
public:
// Types
	class CConvert : public WObject {
	public:
		enum {	// sample units
			VALUE,
			PERCENT,
			DECIBELS,
			UNITS
		};
		CConvert();
		CConvert(const CWave& Wave);
		void	Create(const CWave& Wave);
		SAMPLE	m_NegRail;			// negative rail
		SAMPLE	m_PosRail;			// positive rail
		double	SampleToNorm(double Sample) const;
		double	NormToSample(double Norm) const;
	};
	typedef CArrayEx<double, double> CDblArray;

protected:
};

inline CWaveProcess::CConvert::CConvert(const CWave& Wave)
{
	Create(Wave);
}

#endif
