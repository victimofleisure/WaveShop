// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04dec12	initial version
        01      25jan13	add FindSample
        02      07feb13	in FindClipping, compensate for selection start
        03      25feb13	add Resample
		04		01mar13	in ExtractChannels, add dual progress
		05		01mar13	in ExtractChannels, include channel index in path
        06      02mar13	move speaker names to base class
		07		04mar13	in FindClipping, add clipping level
		08		07mar13	in GetRMSStats, fix integer overflow on negative rail
		09		13mar13	copy channel mask
		10		20mar13	add GetSpectrum
		11		31mar13	use SetPosEx
		12		04apr13	in GetSpectrum, check Analyze return value

		wave processing
 
*/

#include "stdafx.h"
#include "WaveShop.h"
#include "WaveProcess.h"

CWaveProcess::CConvert::CConvert()
{
	m_NegRail = 0;
	m_PosRail = 0;
}

void CWaveProcess::CConvert::Create(const CWave& Wave)
{
	Wave.GetSampleRails(m_NegRail, m_PosRail);
}

double CWaveProcess::CConvert::SampleToNorm(double Sample) const
{
	double	rail = Sample < 0 ? -double(m_NegRail) : double(m_PosRail);
	ASSERT(rail != 0);	// otherwise divide by zero
	return(Sample / rail);
}

double CWaveProcess::CConvert::NormToSample(double Norm) const
{
	double	rail = Norm < 0 ? -double(m_NegRail) : double(m_PosRail);
	return(Norm * rail);
}
