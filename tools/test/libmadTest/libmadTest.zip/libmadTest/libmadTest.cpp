// libmadTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveShop.h"
#include "MadWrap.h"
#include "PathStr.h"
#include "Wave.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWaveShopApp	theApp;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		printf("Fatal Error: MFC initialization failed\n");
		nRetCode = 1;
	}
	else
	{
	//	LPCTSTR	Path = "C:\\temp\\wav\\mp3sweeps-1f\\16Hz-20kHz-Exp-1f-10sec.mp3";
	//	LPCTSTR	Path = "C:\\temp\\wav\\Paradigm_64kb.mp3";
	//	LPCTSTR	Path = "C:\\temp\\wav\\Paradigm_vbr.mp3";
		LPCTSTR	Path = "C:\\Chris\\ftp\\www\\mp3\\motf\\01_This_Is_Cheese.mp3";
	//	LPCTSTR	Path = "C:\\Chris\\ftp\\www\\mp3\\motf\\07_Bones.mp3";
	//	LPCTSTR	Path = "C:\\Chris\\ftp\\www\\mp3\\12_i_just_cant_let_go.mp3";
	//	LPCTSTR	Path = "C:\\temp\\wav\\DemonsInMyHead_vbr.mp3";
	//	LPCTSTR	Path = "C:\\temp\\wav\\ChrisKorda-TheManOfTheFuture.mp3";
		CMadWrap	mad;
		int	quality = CMadWrap::QUAL_16_BIT;
		if (mad.Create(quality)) {
			CWave	wave;
			if (mad.Read(Path, wave)) {
				printf("writing output file\n");
				wave.SafeWrite("dst.wav");
			} else
				printf("input error\n");
		} else
			printf("can't create\n");
	}

	return nRetCode;
}
