#include "stdafx.h"
#include "WaveShop.h"
#include "PathStr.h"
#include "DllWrap.h"
#include <io.h>		// for _open_osfhandle in OpenTempStream

CString CWaveShopApp::GetAppPath()
{
	CString	s = GetCommandLine();
	s.TrimLeft();	// trim leading whitespace just in case
	if (s[0] == '"')	// if first char is a quote
		s = s.Mid(1).SpanExcluding(_T("\""));	// span to next quote
	else
		s = s.SpanExcluding(_T(" \t"));	// span to next whitespace
	return(s);
}

CString CWaveShopApp::GetAppFolder()
{
	CPathStr	path(GetAppPath());
	path.RemoveFileSpec();
	return(path);
}

bool CWaveShopApp::GetTempPath(CString& Path)
{
	LPTSTR	pBuf = Path.GetBuffer(MAX_PATH);
	DWORD	retc = ::GetTempPath(MAX_PATH, pBuf);
	Path.ReleaseBuffer();
	return(retc != 0);
}

bool CWaveShopApp::GetTempFileName(CString& Path, LPCTSTR Prefix, UINT Unique)
{
	CString	TempPath;
	if (!GetTempPath(TempPath))
		return(FALSE);
	if (Prefix == NULL)
		Prefix = m_pszAppName;
	LPTSTR	pBuf = Path.GetBuffer(MAX_PATH);
	DWORD	retc = ::GetTempFileName(TempPath, Prefix, Unique, pBuf);
	Path.ReleaseBuffer();
	return(retc != 0);
}

bool CWaveShopApp::GetDLLFunctions(CDLLWrap& Lib, LPCTSTR LibPath, const int *OrdinalTbl, int Functions, CPtrArray& FuncPtr)
{
	CString	msg;
	if (!Lib.LoadLibrary(LibPath)) {
		msg.Format(IDS_CKUP_CANT_LOAD_DLL, LibPath, GetLastError());
		AfxMessageBox(msg);
		return(FALSE);
	}
	FuncPtr.SetSize(Functions);
	for (int iFunc = 0; iFunc < Functions; iFunc++) {	// for each function
		int	ordinal = OrdinalTbl[iFunc];
		LPVOID	pFunc = Lib.GetProcAddress((LPCTSTR)ordinal);
		if (pFunc == NULL) {	// if we can't get address
			msg.Format(IDS_DLL_CANT_GET_FUNCTION, ordinal, LibPath, GetLastError());
			AfxMessageBox(msg);
			return(FALSE);
		}
		FuncPtr[iFunc] = pFunc;	// store function address in array
	}
	return(TRUE);
}

FILE *CWaveShopApp::OpenTempStream(LPCTSTR Path)
{
	// create temporary file; automatically delete on close
	HANDLE	hFile = CreateFile(Path,
		GENERIC_READ | GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, NULL);
	if (hFile == INVALID_HANDLE_VALUE)	// if create failed
		return(NULL);
	// associate C run-time file handle with OS file handle
	int hCRTFile = _open_osfhandle((long)hFile, 0);
	if (hCRTFile < 0)	// if association failed
		return(NULL);
	// convert C run-time file handle to stream
	return(_fdopen(hCRTFile, "w+"));	// read/write access
}
