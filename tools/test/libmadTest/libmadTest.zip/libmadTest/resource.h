//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by libmadTest.rc
//
#define IDD_PROGRESS                    132
#define IDD_PROGRESS_DUAL               133
#define IDD_PROGRESS_SLAVE              134
#define IDS_CKUP_CANT_LOAD_DLL          200
#define IDS_DLL_CANT_GET_FUNCTION       201
#define IDS_HELLO                       202
#define IDS_WAVE_ERR_BAD_BIT_COUNT      203
#define IDS_WAVE_ERR_BAD_BLOCK_ALIGN    204
#define IDS_WAVE_ERR_BAD_CHANNEL_COUNT  205
#define IDS_WAVE_ERR_BAD_FORMAT_SIZE    206
#define IDS_WAVE_ERR_BAD_SAMPLE_RATE    207
#define IDS_WAVE_ERR_END_OF_FILE        208
#define IDS_WAVE_ERR_NOT_RIFF           209
#define IDS_WAVE_ERR_NOT_WAVE           210
#define IDS_WAVE_ERR_NO_DATA_CHUNK      211
#define IDS_WAVE_ERR_NO_FORMAT_CHUNK    212
#define IDS_WAVE_ERR_UNKNOWN_FORMAT     213
#define IDS_DOC_READING                 214
#define IDS_WEDT_NO_TEMP_FILE_NAME      215
#define IDC_PROGRESS                    1090
#define IDC_PROGRESS_PERCENT            1091
#define IDC_PROGRESS_SUBCAPTION         1092
#define IDC_PROGRESS_SUBPROGRESS        1093

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        214
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
