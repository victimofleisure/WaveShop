// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      09oct12	initial version

		ruler test

*/

// RulerTest.h : main header file for the RULERTEST application
//

#if !defined(AFX_RULERTEST_H__C32E3FDD_2810_46C0_BC2D_52C07B130479__INCLUDED_)
#define AFX_RULERTEST_H__C32E3FDD_2810_46C0_BC2D_52C07B130479__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "MainFrm.h"

/////////////////////////////////////////////////////////////////////////////
// CRulerTestApp:
// See RulerTest.cpp for the implementation of this class
//

class CRulerTestApp : public CWinApp
{
public:
	CRulerTestApp();

// Attributes
	CMainFrame	*GetMain();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRulerTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CRulerTestApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CRulerTestApp theApp;

inline CMainFrame *CRulerTestApp::GetMain()
{
	return((CMainFrame *)m_pMainWnd);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RULERTEST_H__C32E3FDD_2810_46C0_BC2D_52C07B130479__INCLUDED_)
