// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version

        options dialog
 
*/

// OptionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RulerTest.h"
#include "OptionsDlg.h"
#include <afxpriv.h>	// for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog

IMPLEMENT_DYNAMIC(COptionsDlg, CPropertySheet)

const int COptionsDlg::RulerTitle[CChildFrame::RULERS] = {
	IDS_RULER_TOP,
	IDS_RULER_BOTTOM,
	IDS_RULER_LEFT,
	IDS_RULER_RIGHT,
};

#define RK_ZOOM_STEP	_T("ZoomStep")

COptionsDlg::COptionsDlg(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	: CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	m_ZoomStep = theApp.GetProfileInt(REG_SETTINGS, RK_ZOOM_STEP, 150);
	m_psh.dwFlags |= PSH_NOAPPLYNOW;
	for (int iRuler = 0; iRuler < CChildFrame::RULERS; iRuler++) {
		COptsRulerDlg&	dlg = m_RulerDlg[iRuler];
		dlg.SetRulerIdx(iRuler);
		dlg.m_psp.pszTitle = LPCTSTR(RulerTitle[iRuler]);
		dlg.m_psp.dwFlags |= PSP_USETITLE;
		AddPage(&m_RulerDlg[iRuler]);
	}
	AddPage(&m_CommonDlg);
	m_CurPage = 0;
}

COptionsDlg::~COptionsDlg()
{
	theApp.WriteProfileInt(REG_SETTINGS, RK_ZOOM_STEP, m_ZoomStep);
}

BEGIN_MESSAGE_MAP(COptionsDlg, CPropertySheet)
	//{{AFX_MSG_MAP(COptionsDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg message handlers

BOOL COptionsDlg::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	SetActivePage(m_CurPage);	// set current page
	return bResult;
}

W64INT COptionsDlg::DoModal() 
{
	W64INT	retc = CPropertySheet::DoModal();
	return(retc);
}

void COptionsDlg::OnDestroy() 
{
	m_CurPage = GetActiveIndex();
	CPropertySheet::OnDestroy();
}

LRESULT COptionsDlg::OnKickIdle(WPARAM, LPARAM)
{
	SendMessageToDescendants(WM_KICKIDLE, 0, 0, FALSE, FALSE);
	return 0;
}
