//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RulerTest.rc
//
#define IDR_MAINFRAME                   101
#define IDR_RULERTTYPE                  102
#define IDD_ABOUTBOX                    103
#define IDD_OPTS_COMMON                 104
#define IDD_OPTS_RULER                  105
#define IDS_OPTIONS                     200
#define IDS_RULER_BOTTOM                201
#define IDS_RULER_LEFT                  202
#define IDS_RULER_RIGHT                 203
#define IDS_RULER_TOP                   204
#define IDC_OPTS_ZOOM_STEP              1001
#define IDC_RULER_END_MARGIN            1002
#define IDC_RULER_ENFORCE_MARGINS       1003
#define IDC_RULER_HIDE_CLIPPED_VALS     1004
#define IDC_RULER_MAJOR_TICK_LEN        1005
#define IDC_RULER_MINOR_TICK_LEN        1006
#define IDC_RULER_MIN_MAJOR_TICK_GAP    1007
#define IDC_RULER_MIN_MINOR_TICK_GAP    1008
#define IDC_RULER_NUM_FORMAT            1009
#define IDC_RULER_PRECISION             1010
#define IDC_RULER_REVERSE               1011
#define IDC_RULER_SHOW                  1012
#define IDC_RULER_START_MARGIN          1013
#define IDC_RULER_UNIT                  1014
#define ID_EDIT_OPTIONS                 32771

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
