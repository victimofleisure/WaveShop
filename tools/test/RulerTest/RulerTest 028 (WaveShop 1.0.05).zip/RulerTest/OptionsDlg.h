// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version

        options dialog
 
*/

#if !defined(AFX_OPTIONSDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_)
#define AFX_OPTIONSDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog

#include "OptsRulerDlg.h"
#include "OptsCommonDlg.h"
#include "ChildFrm.h"

class COptionsDlg : public CPropertySheet
{
	DECLARE_DYNAMIC(COptionsDlg)
// Construction
public:
	COptionsDlg(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	~COptionsDlg();

// Public data
	int		m_ZoomStep;				// zoom step

// Attributes

// Operations

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsDlg)
	public:
	virtual BOOL OnInitDialog();
	virtual W64INT DoModal();
	//}}AFX_VIRTUAL

// Implementation
protected:
// Generated message map functions
	//{{AFX_MSG(COptionsDlg)
	afx_msg void OnDestroy();
	afx_msg void OnResetAll();
	//}}AFX_MSG
	afx_msg LRESULT	OnKickIdle(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

// Constants
	static const int RulerTitle[CChildFrame::RULERS];

// Member data
	COptsRulerDlg	m_RulerDlg[CChildFrame::RULERS];	// ruler pages
	COptsCommonDlg	m_CommonDlg;	// common page
	int		m_CurPage;				// index of current page

// Helpers
};

inline void AFXAPI DDX_Check(CDataExchange* pDX, int nIDC, bool& value)
{
	BOOL	v = value;
	DDX_Check(pDX, nIDC, v);
	value = v != 0;
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_)
