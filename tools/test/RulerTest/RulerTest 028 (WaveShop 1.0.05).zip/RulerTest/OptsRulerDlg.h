// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version
        01      23mar13	add minimum minor tick gap

        ruler options dialog
 
*/

#if !defined(AFX_OPTSRULERDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_)
#define AFX_OPTSRULERDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptsRulerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptsRulerDlg dialog

class CRulerCtrl;

class COptsRulerDlg : public CPropertyPage
{
// Construction
public:
	COptsRulerDlg();
	~COptsRulerDlg();

// Attributes
	void	SetRulerIdx(int RulerIdx);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptsRulerDlg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
// Generated message map functions
	//{{AFX_MSG(COptsRulerDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	afx_msg LRESULT	OnKickIdle(WPARAM wParam, LPARAM lParam);
	afx_msg void OnUpdateMargins(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()

// Dialog data
	//{{AFX_DATA(COptsRulerDlg)
	enum { IDD = IDD_OPTS_RULER };
	int		m_EndMargin;
	BOOL	m_EnforceMargins;
	BOOL	m_HideClippedVals;
	int		m_MajorTickLen;
	int		m_MinMajorTickGap;
	int		m_MinMinorTickGap;
	int		m_MinorTickLen;
	BOOL	m_Reverse;
	BOOL	m_Show;
	int		m_StartMargin;
	int		m_NumFormat;
	int		m_Precision;
	int		m_Unit;
	//}}AFX_DATA

// Constants

// Member data
	int		m_RulerIdx;

// Helpers
	bool	GetStyle(const CRulerCtrl *Ruler, UINT Mask) const;
	void	SetStyle(CRulerCtrl *Ruler, UINT Mask, bool Enable);
};

inline void COptsRulerDlg::SetRulerIdx(int RulerIdx)
{
	m_RulerIdx = RulerIdx;
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTSRULERDLG_H__84776AB1_689B_46EE_84E6_931C1542871D__INCLUDED_)
