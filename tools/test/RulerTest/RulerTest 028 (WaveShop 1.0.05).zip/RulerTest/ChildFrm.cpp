// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version
        01      23mar13	add minimum minor tick gap

		ruler test MDI child frame
 
*/

// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "RulerTest.h"
#include "RulerTestDoc.h"
#include "RulerTestView.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define RK_CHILD_FRAME	_T("ChildFrame")

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

const CChildFrame::RULER_INFO CChildFrame::m_RulerInfo[RULERS] = {	// must match ruler enum
//	DockStyle		InitShow	BarHeight	MinMajorTickGap	MinMinorTickGap
	{CBRS_TOP,		TRUE,		16,			80,				16},
	{CBRS_BOTTOM,	TRUE,		16,			80,				16},
	{CBRS_LEFT,		TRUE,		80,			30,				12},
	{CBRS_RIGHT,	TRUE,		80,			30,				12},
};

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	m_View = NULL;
	m_DragRuler = -1;
	m_PrevDragPos = 0;
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// override default window class styles CS_HREDRAW and CS_VREDRAW
	// otherwise resizing frame redraws entire view, causing flicker
	cs.lpszClass = AfxRegisterWndClass(	// create our own window class
		CS_DBLCLKS,						// request double-clicks
		theApp.LoadStandardCursor(IDC_ARROW),	// standard cursor
		NULL,									// no background brush
		theApp.LoadIcon(IDR_MAINFRAME));		// app's icon
    ASSERT(cs.lpszClass);

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}

bool CChildFrame::IsRulerVisible(int iRuler) const
{
	ASSERT(IsValidRuler(iRuler));
	return(m_Ruler[iRuler].IsWindowVisible() != 0);
}

void CChildFrame::ShowRuler(int iRuler, bool Enable)
{
	ASSERT(IsValidRuler(iRuler));
	ShowControlBar(&m_Ruler[iRuler], Enable, 0);
}

void CChildFrame::ToggleRuler(int iRuler)
{
	ShowRuler(iRuler, !IsRulerVisible(iRuler));
}

int CChildFrame::FindRuler(CPoint Point) const
{
	for (int iRuler = 0; iRuler < RULERS; iRuler++) {
		CRect	r;
		GetRuler(iRuler)->GetWindowRect(r);
		if (r.PtInRect(Point))
			return(iRuler);
	}
	return(-1);	// not found
}

int CChildFrame::PointToRulerPos(int iRuler, CPoint Point) const
{
	int	pos;
	if (GetRuler(iRuler)->IsVertical())
		pos = Point.y;
	else
		pos = Point.x;
	return(pos);
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message map

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_CREATE()
	ON_WM_MOUSEWHEEL()
	ON_WM_PARENTNOTIFY()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CFont	*pFont = CFont::FromHandle(HFONT(GetStockObject(DEFAULT_GUI_FONT)));
	int	HorzMargin = m_RulerInfo[RULER_LEFT].BarHeight + GetSystemMetrics(SM_CXEDGE);
	for (int iRuler = 0; iRuler < RULERS; iRuler++) {
		CRulerBar&	bar = m_Ruler[iRuler];
		const RULER_INFO&	info = m_RulerInfo[iRuler];
		bar.SetHeight(info.BarHeight);
		UINT	dwStyle = WS_CHILD | info.DockStyle;
		if (info.InitShow)
			dwStyle |= WS_VISIBLE;
		if (!bar.Create(this, dwStyle, 0))
			return -1;
		CRulerCtrl	*pRuler = bar.GetRuler();
		if (!pRuler->IsVertical())	// if horizontal ruler
			pRuler->SetMargins(HorzMargin, HorzMargin);
		pRuler->SetFont(pFont);
		pRuler->SetMinMajorTickGap(info.MinMajorTickGap);	// before updating spacing
		pRuler->SetMinMinorTickGap(info.MinMinorTickGap);	// before updating spacing
		pRuler->UpdateSpacing();	// could call SetZoom instead, it updates spacing
	}

	// find our view in child window list
	CRulerTestView	*pView = NULL;
	CWnd	*pWnd = GetWindow(GW_CHILD);
	while (pWnd != NULL) {
		pView = DYNAMIC_DOWNCAST(CRulerTestView, pWnd);
		if (pView != NULL)
			break;
		pWnd = GetNextWindow();
	}
	ASSERT(pView != NULL);
	if (pView != NULL) {	// if we found view
		m_View = pView;
	}

	return 0;
}

void CChildFrame::RecalcLayout(BOOL bNotify) 
{
	CMDIChildWnd::RecalcLayout(bNotify);
}

void CChildFrame::OnParentNotify(UINT message, LPARAM lParam)
{
	if (message == WM_LBUTTONDOWN) {
		CPoint	point;
		POINTSTOPOINT(point, lParam);
		CPoint	ScrPt(point);
		ClientToScreen(&ScrPt);
		int	iRuler = FindRuler(ScrPt);
		if (iRuler >= 0) {
			SetCapture();
			m_DragRuler = iRuler;
			m_PrevDragPos = PointToRulerPos(iRuler, point);
		}
	}
	CMDIChildWnd::OnParentNotify(message, lParam);
}

void CChildFrame::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_DragRuler >= 0) {
		ReleaseCapture();
		m_DragRuler = -1;
	}
	CMDIChildWnd::OnLButtonUp(nFlags, point);
}

void CChildFrame::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_DragRuler >= 0) {
		int	pos = PointToRulerPos(m_DragRuler, point);
		int	ScrollDelta = m_PrevDragPos - pos;
		m_PrevDragPos = pos;
		CRulerCtrl	*pRuler = GetRuler(m_DragRuler);
		pRuler->ScrollToPosition(pRuler->GetScrollPosition() + ScrollDelta);
	}
	CMDIChildWnd::OnMouseMove(nFlags, point);
}

BOOL CChildFrame::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	int	iRuler = FindRuler(pt);
	if (iRuler >= 0) {
		ASSERT(iRuler < RULERS);
		CRulerCtrl	*pRuler = GetRuler(iRuler);
		double	zoom = pRuler->GetZoom();
		double	ZoomStep = theApp.GetMain()->GetOptionsDlg().m_ZoomStep / 100.0;
		double	delta = abs(zDelta) / WHEEL_DELTA * ZoomStep;
		if (zDelta > 0)
			zoom /= delta;	// zoom in
		else
			zoom *= delta;	// zoom out
		CPoint	ClientPt(pt);
		pRuler->ScreenToClient(&ClientPt);
		int	pos;
		if (pRuler->IsVertical())
			pos = ClientPt.y;
		else
			pos = ClientPt.x;
		pRuler->SetZoom(pos, zoom);
	}
	return CMDIChildWnd::OnMouseWheel(nFlags, zDelta, pt);
}
