// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version
        01      23mar13	add minimum minor tick gap

		ruler test MDI child frame
 
*/

// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__8AAAC8EF_4FC2_4BA9_9D81_545D92487ABD__INCLUDED_)
#define AFX_CHILDFRM_H__8AAAC8EF_4FC2_4BA9_9D81_545D92487ABD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RulerBar.h"

class CRulerTestView;

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();

// Constants
	enum {	// define ruler bars
		RULER_TOP,
		RULER_BOTTOM,
		RULER_LEFT,
		RULER_RIGHT,
		RULERS
	};

// Attributes
public:
	CRulerCtrl	*GetRuler(int iRuler);
	const CRulerCtrl	*GetRuler(int iRuler) const;
	bool	IsRulerVisible(int iRuler) const;
	void	ShowRuler(int iRuler, bool Enable);
	void	ToggleRuler(int iRuler);

// Operations
public:
	int		FindRuler(CPoint Point) const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void RecalcLayout(BOOL bNotify = TRUE);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CChildFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewTopUnitEnglish();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnParentNotify(UINT message, LPARAM lParam);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Types
	struct RULER_INFO {
		UINT	DockStyle;			// docking style
		BOOL	InitShow;			// true if initially shown
		int		BarHeight;			// bar height if horizontal, or width if vertical
		int		MinMajorTickGap;	// minimum distance between major ticks
		int		MinMinorTickGap;	// minimum distance between minor ticks
	};

// Constants
	static const RULER_INFO	m_RulerInfo[RULERS];

// Data members
	CRulerTestView	*m_View;		// pointer to view
	CRulerBar	m_Ruler[RULERS];	// array of rulers
	int		m_DragRuler;			// index of dragged ruler, or -1 if none
	int		m_PrevDragPos;			// previous drag position

// Helpers
	int		PointToRulerPos(int iRuler, CPoint Point) const;
	bool	IsValidRuler(int iRuler) const;
};

inline bool CChildFrame::IsValidRuler(int iRuler) const
{
	return(iRuler >= 0 && iRuler < RULERS);
}

inline CRulerCtrl *CChildFrame::GetRuler(int iRuler)
{
	ASSERT(IsValidRuler(iRuler));
	return(m_Ruler[iRuler].GetRuler());
}

inline const CRulerCtrl *CChildFrame::GetRuler(int iRuler) const
{
	ASSERT(IsValidRuler(iRuler));
	return(m_Ruler[iRuler].GetRuler());
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFRM_H__8AAAC8EF_4FC2_4BA9_9D81_545D92487ABD__INCLUDED_)
