// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      09oct12	initial version

		ruler test document

*/

// RulerTestDoc.cpp : implementation of the CRulerTestDoc class
//

#include "stdafx.h"
#include "RulerTest.h"

#include "RulerTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRulerTestDoc

IMPLEMENT_DYNCREATE(CRulerTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CRulerTestDoc, CDocument)
	//{{AFX_MSG_MAP(CRulerTestDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRulerTestDoc construction/destruction

CRulerTestDoc::CRulerTestDoc()
{
	// TODO: add one-time construction code here

}

CRulerTestDoc::~CRulerTestDoc()
{
}

BOOL CRulerTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CRulerTestDoc serialization

void CRulerTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CRulerTestDoc diagnostics

#ifdef _DEBUG
void CRulerTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CRulerTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRulerTestDoc commands
