// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version

        common options dialog
 
*/

// OptsCommonDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RulerTest.h"
#include "OptsCommonDlg.h"
#include <afxpriv.h>	// for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptsCommonDlg dialog

COptsCommonDlg::COptsCommonDlg()
	: CPropertyPage(IDD)
{
	//{{AFX_DATA_INIT(COptsCommonDlg)
	m_ZoomStep = 0;
	//}}AFX_DATA_INIT
}

COptsCommonDlg::~COptsCommonDlg()
{
}

void COptsCommonDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptsCommonDlg)
	DDX_Text(pDX, IDC_OPTS_ZOOM_STEP, m_ZoomStep);
	DDV_MinMaxInt(pDX, m_ZoomStep, 101, 200);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(COptsCommonDlg, CPropertyPage)
	//{{AFX_MSG_MAP(COptsCommonDlg)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptsCommonDlg message handlers

BOOL COptsCommonDlg::OnInitDialog() 
{
	m_ZoomStep = theApp.GetMain()->GetOptionsDlg().m_ZoomStep;
	CPropertyPage::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COptsCommonDlg::OnOK() 
{
	CPropertyPage::OnOK();
	theApp.GetMain()->GetOptionsDlg().m_ZoomStep = m_ZoomStep;
}

LRESULT COptsCommonDlg::OnKickIdle(WPARAM wParam, LPARAM lParam)
{
    UpdateDialogControls(this, TRUE);
    return FALSE;
}
