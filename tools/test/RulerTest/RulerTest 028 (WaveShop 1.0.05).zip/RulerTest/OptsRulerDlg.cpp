// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04oct12	initial version
        01      23mar13	add minimum minor tick gap

        ruler options dialog
 
*/

// OptsRulerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RulerTest.h"
#include "OptsRulerDlg.h"
#include "ChildFrm.h"
#include <afxpriv.h>	// for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptsRulerDlg dialog

COptsRulerDlg::COptsRulerDlg()
	: CPropertyPage(IDD)
{
	//{{AFX_DATA_INIT(COptsRulerDlg)
	m_EndMargin = 0;
	m_EnforceMargins = FALSE;
	m_HideClippedVals = FALSE;
	m_MajorTickLen = 0;
	m_MinMajorTickGap = 0;
	m_MinorTickLen = 0;
	m_Reverse = FALSE;
	m_Show = FALSE;
	m_StartMargin = 0;
	m_NumFormat = -1;
	m_Precision = 0;
	m_Unit = -1;
	//}}AFX_DATA_INIT
	m_RulerIdx = 0;
}

COptsRulerDlg::~COptsRulerDlg()
{
}

bool COptsRulerDlg::GetStyle(const CRulerCtrl *Ruler, UINT Mask) const
{
	return((Ruler->GetStyle() & Mask) != 0);
}

void COptsRulerDlg::SetStyle(CRulerCtrl *Ruler, UINT Mask, bool Enable)
{
	UINT	remove = 0, add = 0;
	if (Enable)
		add = Mask;
	else
		remove = Mask;
	Ruler->ModifyStyle(remove, add);
}

void COptsRulerDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptsRulerDlg)
	DDX_Text(pDX, IDC_RULER_END_MARGIN, m_EndMargin);
	DDX_Check(pDX, IDC_RULER_ENFORCE_MARGINS, m_EnforceMargins);
	DDX_Check(pDX, IDC_RULER_HIDE_CLIPPED_VALS, m_HideClippedVals);
	DDX_Text(pDX, IDC_RULER_MAJOR_TICK_LEN, m_MajorTickLen);
	DDX_Text(pDX, IDC_RULER_MIN_MAJOR_TICK_GAP, m_MinMajorTickGap);
	DDX_Text(pDX, IDC_RULER_MIN_MINOR_TICK_GAP, m_MinMinorTickGap);
	DDX_Text(pDX, IDC_RULER_MINOR_TICK_LEN, m_MinorTickLen);
	DDX_Check(pDX, IDC_RULER_REVERSE, m_Reverse);
	DDX_Check(pDX, IDC_RULER_SHOW, m_Show);
	DDX_Text(pDX, IDC_RULER_START_MARGIN, m_StartMargin);
	DDX_CBIndex(pDX, IDC_RULER_NUM_FORMAT, m_NumFormat);
	DDX_Text(pDX, IDC_RULER_PRECISION, m_Precision);
	DDX_CBIndex(pDX, IDC_RULER_UNIT, m_Unit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(COptsRulerDlg, CPropertyPage)
	//{{AFX_MSG_MAP(COptsRulerDlg)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
	ON_UPDATE_COMMAND_UI(IDC_RULER_START_MARGIN, OnUpdateMargins)
	ON_UPDATE_COMMAND_UI(IDC_RULER_END_MARGIN, OnUpdateMargins)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptsRulerDlg message handlers

BOOL COptsRulerDlg::OnInitDialog() 
{
	CChildFrame	*pChild = (CChildFrame *)theApp.GetMain()->MDIGetActive();
	if (pChild != NULL) {
		CRulerCtrl	*pRuler = pChild->GetRuler(m_RulerIdx);
		m_Show = pChild->IsRulerVisible(m_RulerIdx);
		m_Reverse = pRuler->GetZoom() < 0;
		m_HideClippedVals = GetStyle(pRuler, CRulerCtrl::HIDE_CLIPPED_VALS);
		m_EnforceMargins = GetStyle(pRuler, CRulerCtrl::ENFORCE_MARGINS);
		m_Unit = pRuler->GetUnit();
		m_NumFormat = pRuler->GetNumericFormat();
		m_Precision = pRuler->GetPrecision();
		m_MinMajorTickGap = pRuler->GetMinMajorTickGap();
		m_MinMinorTickGap = pRuler->GetMinMinorTickGap();
		pRuler->GetTickLengths(m_MajorTickLen, m_MinorTickLen);
		pRuler->GetMargins(m_StartMargin, m_EndMargin);
	}
	CPropertyPage::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COptsRulerDlg::OnOK() 
{
	CPropertyPage::OnOK();
	CChildFrame	*pChild = (CChildFrame *)theApp.GetMain()->MDIGetActive();
	if (pChild != NULL) {
		CRulerCtrl	*pRuler = pChild->GetRuler(m_RulerIdx);
		pChild->ShowRuler(m_RulerIdx, m_Show != 0);
		double	zoom = pRuler->GetZoom();
		if (m_Reverse != zoom < 0) {
			zoom = -zoom;
			pRuler->SetZoom(zoom);
		}
		SetStyle(pRuler, CRulerCtrl::HIDE_CLIPPED_VALS, m_HideClippedVals != 0);
		SetStyle(pRuler, CRulerCtrl::ENFORCE_MARGINS, m_EnforceMargins != 0);
		pRuler->SetUnit(m_Unit);
		pRuler->SetNumericFormat(m_NumFormat, m_Precision);
		pRuler->SetMinMajorTickGap(m_MinMajorTickGap);
		pRuler->SetMinMinorTickGap(m_MinMinorTickGap);
		pRuler->SetTickLengths(m_MajorTickLen, m_MinorTickLen);
		pRuler->SetMargins(m_StartMargin, m_EndMargin);
		pRuler->UpdateSpacing();
	}
}

LRESULT COptsRulerDlg::OnKickIdle(WPARAM wParam, LPARAM lParam)
{
    UpdateDialogControls(this, TRUE);
    return FALSE;
}

void COptsRulerDlg::OnUpdateMargins(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsDlgButtonChecked(IDC_RULER_ENFORCE_MARGINS));
}
