// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      12oct12	initial version

		DirectSound m_Player test
 
*/

// DSPlayerTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DSPlayerTest.h"
#include "conio.h"
#include "Prompt.h"
#include <math.h>
#include "CoInitializer.h"
#include "dxerr8.h"	// for DX error strings

using namespace CPrompt;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

CDSPlayerTest::CDSPlayerTest()
{
}

CDSPlayerTest::~CDSPlayerTest()
{
}

bool CDSPlayerTest::GetDeviceInfo()
{
	if (!CDSPlayer::EnumDevices(m_DevInfo))
		return(FALSE);
	int	devs = m_DevInfo.GetSize();
	_tprintf(_T("%d DirectSound devices found\n"), devs);
	for (int iDev = 0; iDev < devs; iDev++)
		_tprintf(_T("[%d] %s\n"), iDev, m_DevInfo[iDev].m_Description);
	return(TRUE);
}

void CDSPlayerTest::CMyDSPlayer::OnDXError(HRESULT hr) const
{
	_tprintf(_T("%s: %s\n"), DXGetErrorString8(hr), DXGetErrorDescription8(hr));
}

int CDSPlayerTest::TrimTrailingZeros(CString& Str)
{
	int	len = Str.GetLength();
	if (len) {
		LPCTSTR	pStr = Str.GetBuffer(0);
		int	iPos = len - 1;
		while (iPos >= 0 && pStr[iPos] == '0')
			iPos--;
		len = iPos + 1;
		Str.ReleaseBuffer(len);
	}
	return(len);
}

double CDSPlayerTest::FrameToNormPos(W64INT Frame) const
{
	return(double(Frame) / m_Wave.GetFrameCount());
}

W64INT CDSPlayerTest::NormPosToFrame(double NormPos) const
{
	return(roundW64INT(NormPos * m_Wave.GetFrameCount()));
}

CString CDSPlayerTest::FrameToTime(W64INT Frame, int Precision) const
{
	UINT	SampleRate = m_Wave.GetSampleRate();
	int	Ticks = Frame % SampleRate;
	W64INT	TimeSecs = Frame / SampleRate;
	int	seconds = int(TimeSecs % 60);
	TimeSecs /= 60;
	int	minutes = int(TimeSecs % 60);
	int	hours = int(TimeSecs / 60);
	CString	sResult, sFracSec;
	sResult.Format(_T("%d:%02d:%02d"), hours, minutes, seconds);
	double	FracSec = double(Ticks) / SampleRate;
	if (Precision < 0)
		sFracSec.Format(_T("%f"), FracSec);
	else
		sFracSec.Format(_T("%.*f"), Precision, FracSec);
	if (Precision >= 0 || TrimTrailingZeros(sFracSec) > 2)
		sResult += sFracSec.Mid(1);
	return(sResult);
}

bool CDSPlayerTest::TimeToFrame(LPCTSTR Time, W64INT& Frame) const
{
	CString	sTime(Time);
	sTime.Replace(':', ' ');	// allow spaces instead of colons
	int	hours = 0, mins = 0, secs = 0;
	double	ticks = 0;
	if (_stscanf(sTime, _T("%d%d%d%lf"), &hours, &mins, &secs, &ticks) < 1)
		return(FALSE);
	UINT	SampleRate = m_Wave.GetSampleRate();
	Frame = W64INT(hours * 3600 + mins * 60 + secs) * SampleRate 
		+ round(ticks * SampleRate);
	return(TRUE);
}

bool CDSPlayerTest::GetFrameTime(LPCTSTR Prompt, W64INT& Frame)
{
	CString	sTime(FrameToTime(Frame));
	if (!GetVal(Prompt, sTime))
		return(FALSE);
	return(TimeToFrame(sTime, Frame));
}

void CDSPlayerTest::PromptCmd()
{
	static const LPCSTR Help =
		"o  open\n"
		"c  close\n"
		"   play/stop\n"
		"w  rewind\n"
		"v  volume\n"
		"p  pan\n"
		"f  frequency\n"
		"g  go to position\n"
		"r  repeat\n"
		"l  loop points\n"
		"q  quit\n";
	bool	more = TRUE;
	bool	ShowHelp = TRUE;
	while (more) {
		if (ShowHelp) {
			fputs(Help, stdout);
			ShowHelp = FALSE;
		}
		fputs("DSPlayer> ", stdout);
		int	key = _getch();
		printf("%c\n", key);
		switch (key) {
		case 'o':	// open
			if (GetVal(_T("path"), m_WavePath))
				OpenWave(m_WavePath);
			break;
		case 'c':	// close
			if (!m_Player.Close())
				_tprintf(_T("can't close\n"));
			break;
		case ' ':	// play/stop
			if (m_Player.IsPlaying()) {
				if (!m_Player.Stop())
					_tprintf(_T("can't stop\n"));
			} else {
				if (!m_Player.Play())
					_tprintf(_T("can't play\n"));
			}
			break;
		case 'w':	// rewind
			if (!m_Player.Rewind())
				_tprintf(_T("can't rewind\n"));
			break;
		case 'v':	// volume
			{
				double	vol;
				if (m_Player.GetVolume(vol)) {
					if (GetVal(_T("volume [0..1]"), vol)) {
						if (!m_Player.SetVolume(vol))
							_tprintf(_T("can't set volume\n"));
					}
				} else
					_tprintf(_T("can't get volume\n"));
			}
			break;
		case 'p':	// pan
			{
				double	pan;
				if (m_Player.GetPan(pan)) {
					if (GetVal(_T("pan [-1..1]"), pan)) {
						if (!m_Player.SetPan(pan))
							_tprintf(_T("can't set pan\n"));
					}
				} else
					_tprintf(_T("can't get pan\n"));
			}
			break;
		case 'f':	// frequency
			{
				double	freq;
				if (m_Player.GetFrequency(freq)) {
					if (GetVal(_T("frequency [-1..1]"), freq)) {
						if (!m_Player.SetFrequency(freq))
							_tprintf(_T("can't set frequency\n"));
					}
				} else
					_tprintf(_T("can't get frequency\n"));
			}
			break;
		case 'g':	// go to position
			{
				W64INT	frame;
				if (m_Player.GetWritePosition(frame)) {
					if (GetFrameTime(_T("frame"), frame)) {
						if (!m_Player.SetPosition(frame))
							_tprintf(_T("can't set position\n"));
					}
				} else
					_tprintf(_T("can't get position\n"));
			}
			break;
		case 'r':	// repeat
			{
				bool	repeat = m_Player.GetRepeat();
				if (GetYN(_T("repeat [Y/N]"), repeat)) {
					if (!m_Player.SetRepeat(repeat))
						_tprintf(_T("can't set repeat\n"));
				}
			}
			break;
		case 'l':	// loop points
			{
				W64INT	start, end;
				if (m_Player.GetLoopPoints(start, end)) {
					W64INT	NewStart = start;
					W64INT	NewEnd = end;
					GetFrameTime(_T("start frame"), NewStart);
					GetFrameTime(_T("end frame"), NewEnd);
					if (NewStart != start || NewEnd != end) {
						if (!m_Player.SetLoopPoints(NewStart, NewEnd))
							_tprintf(_T("can't set loop points\n"));
					}
				} else
					_tprintf(_T("can't get loop points\n"));
			}
			break;
		case 'q':	// quit
			more = FALSE;
			break;
		default:
			ShowHelp = TRUE;
		}
	}
}

bool CDSPlayerTest::OpenWave(LPCTSTR Path)
{
	// read wave file
	TRY {
		m_Wave.Read(Path);
	}
	CATCH (CFileException, e) {	// also catches CWaveFileException
		TCHAR	msg[256];
		e->GetErrorMessage(msg, _countof(msg));
		_tprintf(_T("%s\n"), msg);
		return(FALSE);
	}
	END_CATCH;
	m_WavePath = Path;	// wave file was opened
	// display wave info
	_tprintf(_T("channels = %d, sample rate = %d, sample bits = %d\n")
			_T("sample size = %d, frame size = %d, bytes per sec = %d\n"),
		   m_Wave.GetChannels(),
		   m_Wave.GetSampleRate(),
		   m_Wave.GetSampleBits(),
		   m_Wave.GetSampleSize(),
		   m_Wave.GetFrameSize(),
		   m_Wave.GetBytesPerSec());
	_tprintf(_T("length = %s (%I64d frames)\n"), 
		FrameToTime(m_Wave.GetFrameCount()),
		LONGLONG(m_Wave.GetFrameCount()));
	// open wave in player
	if (!m_Player.Open(m_Wave)) {
		_tprintf(_T("can't create DirectSound buffer for %s\n"), Path);
		return(FALSE);
	}
	// display player info
	_tprintf(_T("buffer size = %d bytes\n"), m_Player.GetBufferSize());
	return(TRUE);
}

void CDSPlayerTest::NatterMain()
{
	const UINT UpdatePeriod = 50;	// natter period, in milliseconds
	while (m_Natter.WaitForStart()) {
		while (!m_Natter.GetStopFlag()) {
			if (m_Player.IsOpen()) {
				W64INT	frame;
				m_Player.GetPosition(frame);
				CString sTime(FrameToTime(frame, 6));	// precision
				if (sTime != m_CurTime) {
					CString	sTitle;
					sTitle.Format(_T("%s %s"), sTime, m_WavePath);
					SetConsoleTitle(sTitle);
					m_CurTime = sTime;
				}
			}
			Sleep(UpdatePeriod);
		}
	}
}

UINT CDSPlayerTest::NatterFunc(LPVOID pParam)
{
	CDSPlayerTest	*pTest = (CDSPlayerTest *)pParam;
	pTest->NatterMain();
	return(0);
}

bool CDSPlayerTest::MainTest(LPCTSTR Path)
{
	try {
		CCoInitializer	coninit;	// initialize COM
		// create natter thread
		if (!m_Natter.Create(NatterFunc, this, 0, 0, INFINITE))
			return(FALSE);
		if (!m_Natter.Run(TRUE))	// start natter thread running
			return(FALSE);
		if (!GetDeviceInfo()) {	// find DirectSound devices
			_tprintf(_T("can't enumerate DirectSound devices\n"));
			return(FALSE);
		}
		if (!m_DevInfo.GetSize())
			return(FALSE);	// no devices found
		int	iDev = 0;
		_tprintf(_T("using device '%s'\n"), m_DevInfo[iDev].m_Description);
		// create player
		HWND	hWnd = GetDesktopWindow();
		if (!m_Player.Create(&m_DevInfo[iDev].m_Guid, hWnd)) {
			_tprintf(_T("can't create player\n"));
			return(FALSE);
		}
		m_Player.SetRepeat(TRUE);
		if (Path != NULL) {	// if path specified
			if (!OpenWave(Path))	// open wave file
				return(FALSE);
			if (!m_Player.Play()) {	// start playing
				_tprintf(_T("can't play\n"));
				return(FALSE);
			}
		}
		PromptCmd();	// prompt user for commands
	}
	catch (HRESULT) {
		_tprintf("can't initialize COM\n");
		return(FALSE);
	}
	return(TRUE);
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		return 1;
	}
	LPCTSTR	Path = argv[1];
		Path = _T("C:\\temp\\wav\\01ThisIsCheese.wav");
//		Path = _T("C:\\temp\\wav\\Chicago IX (Greatest Hits)\\11 Beginnings.wav");
//		Path = _T("C:\\temp\\wav\\Chris Korda & The Church of Euthanasia - Six Billion Humans Can't Be Wrong\\Chris Korda & The Church of Euthanasia - Six Billion Humans Can't Be Wrong.wav");
//		Path = _T("C:\\temp\\wav\\test\\Error.wav");
//		Path = _T("C:\\temp\\wav\\test\\60hz44k16b.wav");
//		Path = _T("C:\\temp\\wav\\test\\440hz44k16b 10s shaped.wav");
	CDSPlayerTest	test;
	if (!test.MainTest(Path))
		_tprintf(_T("FAIL\n"));
	return 0;
}
