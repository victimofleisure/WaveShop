// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      12oct12	initial version

		DirectSound player test
 
*/

#if !defined(AFX_DSPLAYERTEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_)
#define AFX_DSPLAYERTEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include "DSPlayer.h"
#include "Wave.h"

class CDSPlayerTest : public WObject {
public:
// Construction
	CDSPlayerTest();
	~CDSPlayerTest();

// Operations
	bool	MainTest(LPCTSTR Path);

protected:
// Types
	class CMyDSPlayer : public CDSPlayer {
	protected:
		void CMyDSPlayer::OnDXError(HRESULT hr) const;
	};

// Member data
	CDSPlayer::CDSDeviceInfoArray	m_DevInfo;	// DirectShow device info
	// declare wave BEFORE player to ensure wave outlives player
	CWave	m_Wave;				// wave to play
	CMyDSPlayer	m_Player;		// DirectSound player
	CString	m_CurTime;			// play time as a string
	CString	m_WavePath;			// wave path
	CWorkerThread	m_Natter;	// worker thread to natter current position

// Helpers
	bool	GetDeviceInfo();
	bool	OpenWave(LPCTSTR Path);
	void	PromptCmd();
	static	int		TrimTrailingZeros(CString& Str);
	double	FrameToNormPos(W64INT Frame) const;
	W64INT	NormPosToFrame(double NormPos) const;
	CString	FrameToTime(W64INT Frame, int Precision = -1) const;
	bool	TimeToFrame(LPCTSTR Time, W64INT& Frame) const;
	bool	GetFrameTime(LPCTSTR Prompt, W64INT& Frame);
	void	NatterMain();
	static	UINT	NatterFunc(LPVOID pParam);
};

#endif // !defined(AFX_DSPLAYERTEST_H__16E2AFC1_ABF7_4B92_9F2A_90CB814120DE__INCLUDED_)
