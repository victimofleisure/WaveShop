// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
		chris korda
 
		rev		date		comments
		00		12nov12		initial version
		
		type conversion and prompting templates
 
*/

#pragma once

#include <iostream>
#include <sstream>
#include <string>

namespace CPrompt {

template<class T> static bool StrToVal(LPCTSTR Str, T& Val)
{
#ifdef UNICODE
	std::wstring	s(Str);
	std::wstringstream ss(s);
#else
	std::string	s(Str);
	std::stringstream ss(s);
#endif
	return((ss >> Val) != NULL);
}

template<class T> static bool ValToStr(const T& Val, CString& Str)
{
	std::stringstream ss;
	bool	retc = ((ss << Val) == NULL);
	Str = ss.str().c_str();
	return(retc);
}

// override StrToVal template for CString
static inline bool StrToVal(LPCTSTR Str, CString& Val)
{
	Val = Str;
	return(TRUE);
}

// override ValToStr template for CString
static inline bool ValToStr(const CString& Val, CString& Str)
{
	Str = Val;
	return(TRUE);
}

// override ValToStr template for LPCTSTR
static inline bool ValToStr(LPCTSTR Val, CString& Str)
{
	Str = Val;
	return(TRUE);
}

// override StrToVal template for TCHAR
static inline bool StrToVal(CString& Str, TCHAR& Val)
{
	if (Str.IsEmpty())
		return(FALSE);
	Val = Str[0];
	return(TRUE);
}

// override ValToStr template for TCHAR
static inline bool ValToStr(TCHAR& Val, CString& Str)
{
	Str = Val;
	return(TRUE);
}

template<class T> static bool GetVal(T& Val)
{
	CString	s;
	CStdioFile	fp(stdin);
	if (!fp.ReadString(s) || s.IsEmpty())
		return(FALSE);
	return(StrToVal(s, Val));
}

template<class T> static bool GetVal(LPCTSTR Prompt, T& Val)
{
	CString	s;
	ValToStr(Val, s);
	_tprintf(_T("%s (%s): "), Prompt, s);
	return(GetVal(Val));
}

static bool GetYN(LPCTSTR Prompt, bool& Val)
{
	TCHAR	c = Val ? 'Y' : 'N';
	if (!GetVal(Prompt, c))
		return(FALSE);
	Val = toupper(c) == 'Y';
	return(TRUE);
}

};
