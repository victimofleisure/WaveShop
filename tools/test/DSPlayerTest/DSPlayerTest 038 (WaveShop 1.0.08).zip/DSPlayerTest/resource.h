//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DSPlayerTest.rc
//
#define IDS_WAVE_ERR_BAD_BIT_COUNT      200
#define IDS_WAVE_ERR_BAD_BLOCK_ALIGN    201
#define IDS_WAVE_ERR_BAD_CHANNEL_COUNT  202
#define IDS_WAVE_ERR_BAD_FORMAT_SIZE    203
#define IDS_WAVE_ERR_BAD_SAMPLE_RATE    204
#define IDS_WAVE_ERR_END_OF_FILE        205
#define IDS_WAVE_ERR_NOT_RIFF           206
#define IDS_WAVE_ERR_NOT_WAVE           207
#define IDS_WAVE_ERR_NO_DATA_CHUNK      208
#define IDS_WAVE_ERR_NO_FORMAT_CHUNK    209
#define IDS_WAVE_ERR_UNKNOWN_FORMAT     210
#define IDS_DIRECTSOUND_ERROR           213

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
