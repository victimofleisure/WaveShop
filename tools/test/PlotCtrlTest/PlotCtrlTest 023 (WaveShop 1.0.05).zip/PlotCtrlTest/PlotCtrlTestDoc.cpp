// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      08dec12	initial version

		plot control test document

*/

// PlotCtrlTestDoc.cpp : implementation of the CPlotCtrlTestDoc class
//

#include "stdafx.h"
#include "PlotCtrlTest.h"

#include "PlotCtrlTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestDoc

IMPLEMENT_DYNCREATE(CPlotCtrlTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CPlotCtrlTestDoc, CDocument)
	//{{AFX_MSG_MAP(CPlotCtrlTestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestDoc construction/destruction

CPlotCtrlTestDoc::CPlotCtrlTestDoc()
{
	// TODO: add one-time construction code here

}

CPlotCtrlTestDoc::~CPlotCtrlTestDoc()
{
}

BOOL CPlotCtrlTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestDoc serialization

void CPlotCtrlTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestDoc diagnostics

#ifdef _DEBUG
void CPlotCtrlTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPlotCtrlTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestDoc commands
