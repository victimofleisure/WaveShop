// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      08dec12	initial version

		plot control test document

*/

// PlotCtrlTestDoc.h : interface of the CPlotCtrlTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLOTCTRLTESTDOC_H__BD1D1491_1B9E_4145_84D7_FE9F671D5E62__INCLUDED_)
#define AFX_PLOTCTRLTESTDOC_H__BD1D1491_1B9E_4145_84D7_FE9F671D5E62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPlotCtrlTestDoc : public CDocument
{
protected: // create from serialization only
	CPlotCtrlTestDoc();
	DECLARE_DYNCREATE(CPlotCtrlTestDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlotCtrlTestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPlotCtrlTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPlotCtrlTestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLOTCTRLTESTDOC_H__BD1D1491_1B9E_4145_84D7_FE9F671D5E62__INCLUDED_)
