// Copyleft 2012 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      08dec12	initial version

		plot control test view

*/

// PlotCtrlTestView.cpp : implementation of the CPlotCtrlTestView class
//

#include "stdafx.h"
#include "PlotCtrlTest.h"

#include "PlotCtrlTestDoc.h"
#include "PlotCtrlTestView.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView

IMPLEMENT_DYNCREATE(CPlotCtrlTestView, CView)

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView construction/destruction

CPlotCtrlTestView::CPlotCtrlTestView()
{
	// TODO: add construction code here

}

CPlotCtrlTestView::~CPlotCtrlTestView()
{
}

BOOL CPlotCtrlTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;	// prevent flicker
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView drawing

void CPlotCtrlTestView::OnDraw(CDC* pDC)
{
	CPlotCtrlTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView printing

BOOL CPlotCtrlTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPlotCtrlTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPlotCtrlTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView diagnostics

#ifdef _DEBUG
void CPlotCtrlTestView::AssertValid() const
{
	CView::AssertValid();
}

void CPlotCtrlTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPlotCtrlTestDoc* CPlotCtrlTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPlotCtrlTestDoc)));
	return (CPlotCtrlTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView message map

BEGIN_MESSAGE_MAP(CPlotCtrlTestView, CView)
	//{{AFX_MSG_MAP(CPlotCtrlTestView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlotCtrlTestView message handlers

int CPlotCtrlTestView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	struct DBL_RANGE {
		double	Start;
		double	End;
	};
	static const DBL_RANGE	range[CPlotCtrl::RULERS] = {
		{-1,	1},	// left
		{0,		1},	// top
		{-1,	1},	// right
		{0,		1},	// bottom
	};
	DWORD	style = 
//		CPlotCtrl::DEFAULT_STYLE
		WS_CHILD | WS_VISIBLE
		| CPlotCtrl::HIDE_CLIPPED_VALS
		| CPlotCtrl::PLOT_BORDER
		| CPlotCtrl::HORZ_MAJOR_GRID
		| CPlotCtrl::VERT_MAJOR_GRID
//		| CPlotCtrl::HORZ_MINOR_GRID 
//		| CPlotCtrl::VERT_MINOR_GRID
		| CPlotCtrl::DATA_TIPS
	;
	if (!m_Plot.Create(style, CRect(0, 0, 0, 0), this, 456))
		return -1;
	m_Plot.SendMessage(WM_SETFONT, WPARAM(GetStockObject(DEFAULT_GUI_FONT)));
//	m_Plot.SetFitToData(0);
	const bool UseLogScale[CPlotCtrl::RULERS] = {
		0,	// left
		0,	// top
		0,	// right
		1,	// bottom
	};
	for (int iRuler = 0; iRuler < CPlotCtrl::RULERS; iRuler++) {
		CRulerCtrl&	ruler = m_Plot.GetRuler(iRuler);
//		m_Plot.SetRange(iRuler, CDblRange(range[iRuler].Start, range[iRuler].End));
//		ruler.SetTickLengths(8, 4);
//		ruler.SetNumericFormat(CRulerCtrl::NF_FIXED, 3);
		if (UseLogScale[iRuler])
			ruler.SetUnit(CRulerCtrl::UNIT_LOG);
	}
	int	marg = 10;
	m_Plot.SetMargins(CRect(marg, marg, marg, marg));
	static const COLORREF	color[CPlotCtrl::COLORS] = {
		RGB(128, 128, 128),		// background
		RGB(0, 0, 0),			// plot background
		RGB(128, 128, 128),		// grid
		RGB(255, 255, 255),		// text
		RGB(255, 255, 255),		// border
	};
//	for (int iColor = 0; iColor < CPlotCtrl::COLORS; iColor++)
//		m_Plot.SetColor(iColor, color[iColor]);
	m_Plot.SetVisibleRulers(0
		| CPlotCtrl::RM_LEFT 
		| CPlotCtrl::RM_BOTTOM
//		| CPlotCtrl::RM_RIGHT 
//		| CPlotCtrl::RM_TOP
	);
	CPlotCtrl::CSeries	ser;
	if (1) {
		int	pts = 100;
		ser.m_Point.SetSize(pts + 1);
		double	freq = 1;
		double	delta = PI * 2 * freq / pts;
		double	xscale = 300;
		double	xoffset = 10;
		double	yscale = 1;
		double	yoffset = 0;
		for (int iPt = 0; iPt <= pts; iPt++) {
			double	x = double(iPt) / pts * xscale + xoffset;
			double	y = sin(delta * iPt) * yscale + yoffset;
			ser.m_Point[iPt] = DPoint(x, y);
		}
	} else {
		int	pts = 3;
		ser.m_Point.SetSize(pts);
//		ser.m_Point[0] = DPoint(.49, .3);
//		ser.m_Point[1] = DPoint(.7, -.4);
//		ser.m_Point[2] = DPoint(.9, .5);
		ser.m_Point[0] = DPoint(10, .1);
		ser.m_Point[1] = DPoint(1000, 30);
		ser.m_Point[2] = DPoint(50, 100);
	}
	ser.m_Flags = 0
		| CPlotCtrl::SER_LINE
		| CPlotCtrl::SER_FILL
		| CPlotCtrl::SER_MARKER_LINE
//		| CPlotCtrl::SER_MARKER_FILL
//		| CPlotCtrl::SER_TRANSPARENT
		| CPlotCtrl::SER_FILL_BASELINE
	;
	ser.m_PenWidth = 1;
	ser.m_PenStyle = PS_SOLID;//PS_DASH;
	ser.m_PenColor = RGB(255, 0, 0);
	ser.m_BrushColor = RGB(0, 0, 255);
	ser.m_BrushHatch = -1;//HS_BDIAGONAL;
	ser.m_BkColor = RGB(0, 255, 0);
	ser.m_MarkerStyle = 
		CPlotCtrl::MARK_SQUARE
//		CPlotCtrl::MARK_CIRCLE
//		CPlotCtrl::MARK_DIAMOND
//		CPlotCtrl::MARK_TRIANGLE
	;
//	ser.m_Baseline = -.2;
//	ser.m_MarkerSize = 6;
	m_Plot.InsertSeries(0, ser);
	m_Plot.Update();
	return 0;
}

void CPlotCtrlTestView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	m_Plot.MoveWindow(0, 0, cx, cy);	
}
